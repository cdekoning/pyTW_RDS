"""
Contains an abstract class  defining the interface for TofDaqRec objects - currently implemented in a Local and a Remote concrete class
"""
from abc import ABC, abstractmethod
from typing import Union, List, Tuple, NamedTuple
import numpy as np
import numpy.typing as npt
from datetime import datetime
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).absolute().parent.parent))
from pyrec.DataStructures import (SharedMemoryDesc, PeakPar, MassCalibrationData,
                                  RegisteredDataType, RegisteredDataSource, TpsStatus, TpsModule,
                                  MassSpectrumData, SetFileType, ReturnType,
                                  SegmentProfileData, DioState, ConfigWindow, IonMode)


class TofDaqRec(ABC):
    """
    Class representing a TofDaqRec object with methods calling the low level TofDaq API for python
    """

    @abstractmethod
    def get_dll_version(self) -> float:
        """
        Returns the current dll version

        Returns:
            float: dll version
        """
        pass

    @abstractmethod
    def initialize_dll(self) -> None:
        """
        Initializes the dll
        Raises:
            TofDaqUnspecifiedError: initialization failed
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def cleanup_dll(self) -> None:
        """
        Clean up the dll
        """
        pass

    @abstractmethod
    def is_tofdaq_running(self) -> bool:
        """
        Check if tofdaqrec is running

        Returns:
            bool
        """
        pass

    @abstractmethod
    def is_acquisition_active(self) -> bool:
        """
        Check if there is an active acquisition

        Returns:
            bool
        """
        pass

    @abstractmethod
    def start_acquisition(self) -> None:
        """
        Start a TofDaqRec acquisition
        
        Raises:
            TofDaqRecNotRunningError: No recording application was found
            TofDaqTimeoutError: No successful start was confirmed
            TofDaqUnspecifiedError: Event abandoned or untreated error
            TofDaqException: Unexpected tofdaq exception
        
        """
        pass

    @abstractmethod
    def stop_acquisition(self) -> None:
        """Stop the TofDaqRec acquisition

        Raises:
            TofDaqRecNotRunningError: No recording application was found
            TofDaqTimeoutError: No successful stop was confirmed
            TofDaqUnspecifiedError: Event abandoned or untreated error
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def continue_acquisition(self) -> None:
        """
        Continue acquisition

        Raises:
            TofDaqRecNotRunningError: No recording application was found
            TofDaqNoActiveAcquisitionError: No active to continue
            TofDaqTimeoutError: No successful continue was confirmed
            TofDaqUnspecifiedError: TofDaqRec does not expect a continue signal
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def manual_continue_needed(self) -> bool:
        """
        Check if the acquisition is paused

        Returns:
            bool
        """
        pass

    @abstractmethod
    def close_tofdaq_rec(self) -> None:
        """
        Close TofDaqRec

        Raises:
            TofDaqRecNotRunningError: No recording application was found
            TofDaqTimeoutError: No successful shutdown was confirmed
            TofDaqUnspecifiedError: Unspecified error
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def recorder_needs_restart(self) -> bool:
        """
        Check if the recorder needs to be restarted

        Returns:
            bool: _description_
        """
        pass

    @abstractmethod
    def set_timeout(self, timeout: int) -> None:
        """
        Set timeout for API calls

        Args:
            timeout (int): timeout in ms
        """
        pass

    @abstractmethod
    def get_timeout(self) -> int:
        """
        Get timeout for API calls

        Returns:
            int: timeout in ms
        """
        pass

    @abstractmethod
    def auto_setup_daq_device(self) -> None:
        """
        This function is only functional for AP240 and ndigo5G hardware. For all other setups it returns success
        immediately but does not do anything.

        Raises:
            TofDaqRecNotRunningError - No recording application was found
            TofDaqAcquisitionActiveError - Active acquisition
            TofDaqTimeoutError - No confirmation of successful setup received within 10 seconds
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def initialize_daq_device(self) -> None:
        """
        Initializes the DAQ board (repeats what is happening at startup of TofDaqRec.exe). This can take up to
        8(!) seconds depending on the actual DAQ hardware.

        Raises:
            TofDaqRecNotRunningError - No recording application was found
            TofDaqAcquisitionActiveError - Active acquisition
            TofDaqTimeoutError - No confirmation of successful setup received within 10 seconds
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def issue_dio4_pulse(self, delay: int, width: int) -> None:
        """
        Issues a TTL pulse on the digital output line 4 specified by a delay and a pulse width. Note that in order for
        this command to work Dio4Mode must be set to 2 or 3 (pulsed or manual)

        Args:
            delay: delay before issuing pulse in ms
            width: pulse width in ms

        Raises:
            TofDaqRecNotRunningError - No recording application was found
            TofDaqNoActiveAcquisitionError - No active acquisition
            TofDaqOutOfBoundsError - Invalid parameters - either delay or width are invalid
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def set_dio4_state(self, state: DioState) -> None:
        """
        Manually switches digital output line between states. Note that in order for this command to work Dio4Mode
        must be set to 2 or 3 (pulsed or manual).

        Args:
            state (DioState): enum with labeled values of the possible states

        Raises:
            TofDaqRecNotRunningError - No recording application was found
            TofDaqNoActiveAcquisitionError - No active acquisition
            TofDaqUnspecifiedError - unable to access digital line
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def waiting_for_dio_start_signal(self) -> bool:
        """
        Allows to query whether TofDaq recorder is currently waiting for a digital start signal (or the SW override
        signal, see TwSendDioStartSignal). Note that a TwStartAcquisition needs to be issued before this function can
        return true. It can take several seconds from the moment TwStartAcquisition is called until this function returns true.

        Returns:
            - True:	TofDaq recorder is waiting for a start signal
            - False: TofDaq recorder is not waiting for a start signal
        """
        pass

    @abstractmethod
    def send_dio_start_signal(self) -> bool:
        """
        Software override of digital start signal as configured with DioStart… TofDaq recorder parameters. See also
        TwWaitingForDioStartSignal for finding out when this function can be called successfully.

        Raises:
            TofDaqRecNotRunningError - No recording application was found
            TofDaqNoActiveAcquisitionError - No active acquisition
            TofDaqUnspecifiedError - check the debug output
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def is_dio_start_delay_active(self) -> bool:
        """
        Signals “true” when a start signal was received and “DioStartDelay” is active. Goes “false” when start delay has
         expired. In combination with “TwWaitingForDioStartSignal” can be used to indicate to the user what the current
         experiment state is when digital start signal (and delay) is used.
        Returns:
            bool:
                - True: TofDaq recorder has received a start signal and is now waiting for DioStartDelay to pass
                - False: TofDaq recorder is in any other state

        """
        pass


    @abstractmethod
    def move_last_acquisition_datafiles(self, destination_path: Union[str, Path]) -> None:
        """
        Move or download the h5 files from the latest acquisition to the folder specified

        Args:
            destination_path Union[str, Path]: path if the destination folder
        """
        pass
    # ----------------------- CONFIGURATION FUNCTIONS -------------------------------
    @abstractmethod
    def show_config_window(self, config_window_tab: ConfigWindow = ConfigWindow.daq_tab) -> None:
        """
        Unified function to show the different tabs of the TofDaq recorder configuration form

        Args:
            config_window_tab: enumerator for the tabs of the TofDaqRec configuration window

        Raises:
            TofDaqUnspecifiedError - unknown error
            TofDaqException: Unexpected tofdaq exception

        """
        pass

    @abstractmethod
    def load_ini_file(self, ini_filename: Union[str, None] = None) -> None:
        """
        Load a TofDaqRec .ini file. If no argument is passed, ini_filename defaults to None and uses TwApiTmpIni.ini in TofDaq recorder directory.

        Args:
            ini_filename (Union[str, None], optional): Path to the inifile. Defaults to None.

        Raises:
            TofDaqRecNotRunningError: No recording application was found
            TofDaqAcquisitionActiveError: Acquisition already active
            TofDaqTimeoutError: No successful file load was confirmed
            FileNotFoundError: The specified configuration file could not be found
            TofDaqUnspecifiedError: The specified configuration file is too long (>255 char)
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def save_ini_file(self, ini_filename: Union[str, None] = None) -> None:
        """
        Save the current TofDaqRec settings to a file.If no argument is passed, ini_filename defaults to None and uses TwApiTmpIni.ini in TofDaq recorder directory.

        Args:
            ini_filename (Union[str, None], optional): Path to the inifile. Defaults to None.

        Raises:
            TofDaqRecNotRunningError: No recording application was found
            TofDaqAcquisitionActiveError: Acquisition already active
            TofDaqTimeoutError: No successful file save was confirmed
            FileNotFoundError: The path specified in IniFile does not exist or no permission to create file
            TofDaqUnspecifiedError: The specified configuration file is too long (>255 char)
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def get_daq_parameter(self, parameter: str) -> Union[str, int, bool, float]:
        """
        Get a DAQ parameter

        Args:
            parameter (str): parameter name

        Returns:
            Union[str, int, bool, float]: Returned type depends on the parameter checked
        """
        pass

    @abstractmethod
    def set_daq_parameter(self, parameter: str, value: Union[str, int, bool, float], auto_adjust_value: bool = True) \
            -> Union[str, int, bool, float]:
        """
        Set a DAQ parameter. return the value in case it was adjusted by TofDaqRec
        
        Args:
            parameter (str): parameter name
            value(Union[str, int, bool, float]): parameter value
            auto_adjust_value (bool): Control if TofDaq can adjust a parameter value or if it should throw an exception when the parameter is invalid. Defaults to True
        
        Raises:
            TypeError: Invalid type for Daq parameters
            TofDaqRecNotRunningError: No recording application was found
            TofDaqAcquisitionActiveError: Acquisition already active
            TofDaqInvalidParameterError: Unknown parameter
            TofDaqInvalidValueError: Value type not compatible with parameter
            TofDaqValueAdjustedWarning: The value could not be set as it should have been adjusted
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    # ---------------------------- DATA ACCESS FUNCTIONS ----------------------------
    @abstractmethod
    def get_descriptor(self) -> SharedMemoryDesc:
        """
        Return the descriptor of the current acquisition

        Raises:
            TofDaqRecNotRunningError: No recording application was found
            TofDaqUnspecifiedError: Untreated error
            TofDaqException: Unexpected tofdaq exception

        Returns:
            SharedMemoryDesc: object containing the information on the the descriptor - accessible with dot notation
        """
        pass

    @abstractmethod
    def get_peak_parameters(self, peak_index: int) -> PeakPar:
        """
        Return information on a specific peak in the TofDaq peak list

        Args:
            peak_index (int): index of the peak

        Raises:
            TofDaqRecNotRunningError: No recording application was found
            TofDaqUnspecifiedError: Untreated error
            TofDaqOutOfBoundsError: The peak index is not in range
            TofDaqException: Unexpected tofdaq exception

        Returns:
            PeakPar: object containing the information on the peak
        """
        pass

    @abstractmethod
    def wait_for_new_data(self, timeout: int = 250, wait_for_event_reset: bool = True) \
            -> SharedMemoryDesc:
        """
        Waits for new data and updates shared memory descriptor and shared memory pointers. The function returns when new data is available or when timed out.


        Raises:
            TofDaqRecNotRunningError: No recording application was found
            TofDaqUnspecifiedError: Memory mapping failed
            TofDaqNoDataError: No data is recorded or memory not yet allocated
            TofDaqTimeoutError: No new data available after
            TofDaqException: Unexpected tofdaq exception

        Returns:
            SharedMemoryDesc: return object containing the information on the descriptor
        """
        pass

    @abstractmethod
    def wait_for_end_of_acquisition(self, timeout: int) -> None:
        """
        Wait for the end of the TofDaq acquisiion

        Args:
            timeout (int): timeout in ms

        Raises:
            TofDaqRecNotRunningError: No recording application was found
            TofDaqNoActiveAcquisitionError: No active acquisition
            TofDaqTimeoutError: No new data available during after timeout
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def get_mass_calibration(self, segment_index: int = 0, buf_index: int = 0) \
            -> MassCalibrationData:
        """
        Get information on the mass calibration

        Raises:
            TofDaqRecNotRunningError: No recording application was found
            TofDaqTimeoutError: No mass calibration data retrieved after timeout
            TofDaqException: Unexpected tofdaq exception

        Returns:
            MassCalibrationData: object with information on the mass calibration
        """
        pass

    @abstractmethod
    def set_mass_calibration(self, mass_cal: MassCalibrationData, segment_index: int = 0, buf_index: int = 0) -> None:
        """
        Adjust the mass calibration in tofdaqrec for the current or the next acquisition (depending on the mass calibration dimensionality)

        Args:
            mass_cal (MassCalibrationData): package of mass calibration data to be set
            segment_index (int, optional): segment index for which the mass calibration should be applied. Defaults to 0.
            buf_index (int, optional): buffer index for which. Defaults to 0.

        Raises:
            TofDaqRecNotRunningError: No recording application was found
            TofDaqTimeoutError: No mass calibration data could be set within the timeout
            TofDaqAcquisitionActiveError: Acquisition already active
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def get_sum_spectrum(self, spectrum: Union[npt.NDArray[np.float64], None] = None, normalize: bool = True,
                         return_type: ReturnType = ReturnType.spectrum) -> MassSpectrumData:
        """
        Get the spectrum summed over all segments
        
        Args:
            spectrum (Union[npt.NDArray[np.float64], None], optional): empty numpy array with length nbr_samples.
                                                             Defaults to None - The array will be created by this function
            normalize (bool, optional): flag indicating whether the sum is normalized to a per extraction value. Defaults to True
            return_type (ReturnType, optional): flag indicating if the user will get a Mass spectrum data object with
                                                only the sum spectrum (ReturnType.array) or if the object will include
                                                mass axis and time bin associated with it (ReturnType.spectrum).
                                                Defaults to ReturnType.spectrum

        Raises:
            TofDaqRecNotRunningError: No recording application was found
            TofDaqNoDataError: Sum spectrum data not available
            TofDaqUnspecifiedError: Unspecified TofDaqError
            TofDaqException: Unexpected tofdaq exception

        Returns:
            MassSpectrumData: Spectrum and unit associated with it
        """
        pass

    @abstractmethod
    def get_tof_spectrum(self, spectrum: Union[npt.NDArray[np.float32], None] = None, start_segment: int = 0,
                         end_segment: int = 0, buf_index: int = -1, normalize: bool = True,
                         return_type: ReturnType = ReturnType.spectrum) -> MassSpectrumData:
        """
        Copies a single TOF spectrum (possibly averaged/summed over segment dimension) from shared memory. 
        Starting from TofDaq 1.94 this function accepts a special set of arguments (SegmentIndex = SegmentEndIndex = -1) 
        to copy the complete block of data. When using this argument set Spectrum must be NbrSamples*NbrSegments floats 
        long and Normalize flag is ignored
        
        Args:
            spectrum (Union[npt.NDArray[np.float64], None]): array of floats of minimal length NbrSamples 
                                                            (NbrSamples*NbrSegments if used with SegmentIndex = SegmentEndIndex = -1).
                                                            Defaults to None - The array will be created by this function
            start_segment (int, optional): segment start index of data to fetch (or -1 for complete block copy). Defaults to 0
            end_segment (int, optional): segment end index of data to fetch (or -1 for complete block copy). Defaults to 0
            buf_index (int, optional): buf index of data to fetch. If -1 returns the latest buffer. Defaults to -1
            normalize (bool, optional): flag indicating whether the sum is normalized to a per extraction value. . Defaults to True
            return_type (ReturnType, optional): flag indicating if the user will get a Mass spectrum data object with
                                                only the sum spectrum (ReturnType.array) or if the object will include
                                                mass axis and time bin associated with it (ReturnType.spectrum).
                                                Defaults to ReturnType.spectrum

        Raises:
            TofDaqInvalidValueError: Invalid segment range passed
            TofDaqRecNotRunningError: No recording application was found
            TofDaqNoDataError: Tof spectrum data not available
            TofDaqUnspecifiedError: Unspecified error
            TofDaqOutOfBoundsError: At least one of the indices is out of valid range
            TofDaqException: Unexpected tofdaq exception

        Returns:
            MassSpectrumData: Spectrum and unit associated with it
        """
        pass

    @abstractmethod
    def get_mass_axis(self, specAxis: Union[npt.NDArray[np.float64], None] = None, start_segment: int = -1,
                      end_segment: int = -1, buf_index: int = -1) -> Tuple[npt.NDArray[np.float64], str]:
        """
        Get the x axis in mass/charge [Th]. can average over a range of segments

        Args:
            specAxis (Union[npt.NDArray[np.float64], None], optional): array of doubles of minimal length NbrSamples. 
                                                                       Defaults to None - The array will be created by this function
            start_segment (int, optional): segment start index of data to fetch (or -1 for complete block copy). Defaults to -1.
            end_segment (int, optional): segment end index of data to fetch (or -1 for complete block copy). Defaults to -1.
            buf_index (int, optional): Buf index of data to fetch. If -1 returns the data for the latest buffer. Defaults to -1.

        Raises:
            TofDaqUnspecifiedError: Unspecified error
            TofDaqException: Unexpected tofdaq exception

        Returns:
            Tuple[npt.NDArray[np.float64], str]: array of doubles for the mass axis, with unit
        """
        pass

    @abstractmethod
    def get_stick_spectrum(self, stick_spectrum: Union[npt.NDArray[np.float32], None] = None,
                           masses: Union[npt.NDArray[np.float32], None] = None,
                           start_segment: int = -1, end_segment: int = -1, buf_index: int = -1,
                           return_type: ReturnType = ReturnType.spectrum) -> MassSpectrumData:
        """
        Copies a single stick spectrum from shared memory.
        
        Args:
            stick_spectrum (Union[npt.NDArray[np.float32], None], optional): array of floats of minimal length NbrPeaks. Defaults to None - 
                                                                             the array is created by the function in this case
            masses (Union[npt.NDArray[np.float32], None], optional): array of floats of minimal length NbrPeaks. Defaults to None
            start_segment (int, optional): segment start index of data to fetch (or -1 for complete block copy). Defaults to -1.
            end_segment (int, optional): segment end index of data to fetch (or -1 for complete block copy). Defaults to -1.
            buf_index (int, optional): Buf index of data to fetch. If -1 returns the latest buffer. Defaults to -1.
            return_type (ReturnType, optional): flag indicating if the user will get a Mass spectrum data object with
                                                only the sum spectrum (ReturnType.array) or if the object will include
                                                mass axis and time bin associated with it (ReturnType.spectrum).
                                                Defaults to ReturnType.spectrum

        Raises:
            TofDaqRecNotRunningError: No recording application was found
            TofDaqNoDataError: Tof spectrum data not available
            TofDaqUnspecifiedError: Unspecified error
            TofDaqOutOfBoundsError: At least one of the indices is out of valid range
            TofDaqException: Unexpected tofdaq exception

        Returns:
            MassSpectrumData: Spectrum and unit associated with it
        """
        pass

    @abstractmethod
    def get_segment_profile(self, segment_profile: Union[npt.NDArray[np.float32], None] = None,
                            peak_index: Union[List[int], int] = -1, buf_index: int = -1) -> List[SegmentProfileData]:
        """
        Copies the segment profile for a given peak and buf index from shared memory


        Args:
            segment_profile (Union[npt.NDArray[np.float32], None], optional): array of floats of minimal length NbrSegments (NbrSegments*NbrPeaks if PeakIndex is -1). 
                                                                              Defaults to None - the array is created by this function
            peak_index (Union[List[int], int], optional): peak index of profile to fetch (or list of them). Use -1 for all (NbrPeaks) profiles. Defaults to -1.
            buf_index (int, optional): buf index of profile to fetch. If -1 returns the latest buffer. Defaults to -1.

        Raises:
            TofDaqRecNotRunningError: No recording application was found
            TofDaqNoDataError: Data not available for peak index
            TofDaqUnspecifiedError: Unspecified TofDaqError
            TofDaqOutOfBoundsError: At least one of the indices is out of valid range for peak index
            TofDaqException: Unexpected tofdaq exception

        Returns:
            List[SegmentProfileData]: List of objects storing information on the peak label and its profile over the segment #
        """
        pass

    @abstractmethod
    def get_spec_time(self, buf_index: int = 0, write_index: int = -1) -> float:
        """
        Copies the time stamp for a given buf and write.

        Args:
            buf_index (int, optional): buf index of timestamp to fetch. Defaults to 0.
            write_index (int, optional): write index of timestamp to fetch. Defaults to -1 (latest write).

        Raises:
            TofDaqRecNotRunningError: No recording application was found
            TofDaqNoDataError: Time data not available
            TofDaqUnspecifiedError: Unspecified error
            TofDaqOutOfBoundsError: At least one of the indices is out of valid range
            TofDaqException: Unexpected tofdaq exception

        Returns:
            float: buffer timestamp
        """
        pass

    # @abstractmethod
    # def generate_segment_profiles_from_event_data(self, nbr_profiles: int, mass_ranges: List[Tuple[float, float]],
    #                                               bufIndex: int, data: Union[npt.NDArray[np.float64], None],
    #                                               tofSpec: Union[None, npt.NDArray[np.float32]] = None,
    #                                               startEndInSamples: bool = False) \
    #         -> Tuple[npt.NDArray[np.float64], Union[None, npt.NDArray[np.float32]]]:
    #     pass

    @abstractmethod
    def store_file(self, file_location: str, vfs_location: str) -> None:
        """
        Store a file in the specified virtual file system location in the h5 file
        Args:
            file_location: Path to the file to store
            vfs_location: location in the h5 file where the file should be stored

        Raises:
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    # ------------------- DATA STORAGE FUNCTIONS -----------------------------------
    @abstractmethod
    def add_log_entry(self, log_entry: str, log_entry_time: Union[datetime, int] = 0) -> None:
        """
        Add an entry into the log contained in the h5 file

        Args:
            log_entry (str): text to be saved into the log. Max 255 character including the terminal null
            log_entry_time (Union[datetime, int], optional): time associated with the log entry -  can be a datetime, an integer 
                                                             (time in seconds since the acquisition start) or 0 - the current time. 
                                                             Defaults to 0.

        Raises:
            TofDaqRecNotRunningError: No recording application was found
            TofDaqNoActiveAcquisitionError: No active acquisition
            TofDaqUnspecifiedError: Unspecified error
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def add_attribute(self, obj_name: str, attribute_name: str, value: Union[int, float, str]) -> None:
        """
        Add an attribute to a dataset or a group being stored in the h5 file during acquisition

        Args:
            obj_name (str): Name of a group or a dataset in the h5 file
            attribute_name (str): name of the attribute to create
            value (Union[int, float, str]): value to be set

        Raises:
            TypeError: Invalid type for parameter value
            TofDaqRecNotRunningError: No recording application was found
            TofDaqNoActiveAcquisitionError: No active acquisition
            TofDaqUnspecifiedError: Unspecified TofDaq error
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def rds_add_user_data(self, location: str, data: npt.NDArray[np.float64], element_description: Union[List[str], None]=None,
                     compression_level: int = 4) -> None:
        """
        This function stores user supplied data asynchronously to the TOF data acquistion into the data file being currently recorded. 
        Creates datasets “Data” and “Info” at Location.

        Args:
            location (str): location of group in HDF5 file where the datasets are created
            data (npt.NDArray[np.float64]): double array of length NbrElements holding the actual data to be stored in dataset “Data”.
                                            Max length is 1048575. 
            element_description (Union[List[str], None], optional): text description of elements, if ElementDescription is NULL the 
                                                                    dataset “Info” is not created. Defaults to None.
            compression_level (int, optional): ZLIB compression level (0-9) for dataset creation. If the dataset at Location already 
                                               exists this parameter has no effect. Defaults to 4.

        Raises:
            TofDaqRecNotRunningError: No recording application was found
            TofDaqNoActiveAcquisitionError: No active acquisition
            TofDaqTimeoutError: No successful start was confirmed within Timeout
            TofDaqOutOfBoundsError: Size mismatch between the existing dataset and the data to be added
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def rds_add_source(self, location: str, element_description: List[str], compression_level: int = 4,
                registered_data_type: RegisteredDataType = RegisteredDataType.buffer) -> None:
        """
        These functions store user supplied data synchronously to the TOF data acquistion (data can be stored for all bufs or all writes) 
        into the data file being currently recorded. Creates datasets “TwData” and “TwInfo” at Location. Note that you can not supply 
        initial values for the data elements using these functions. 

        Args:
            location (str): location of group in HDF5 file where the datasets are created
            element_description (List[str]): text description of elements
            compression_level (int, optional): ZLIB compression level (0-9) for dataset creation. If the dataset at Location already 
                                               exists this parameter has no effect. Defaults to 4.
            registered_data_type (RegisteredDataType, optional): Type of registered data to create. Defaults to RegisteredDataType.buffer.

        Raises:
            TypeError: Invalid type specified for the registered data
            TofDaqRecNotRunningError: No recording application was found
            TofDaqAcquisitionActiveError: Acquisition already active - cannot register
            TofDaqUnspecifiedError: Unspecified error
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def rds_remove_source(self, location: str) -> None:
        """
        Unregisters a data source previously registered

        Args:
            location (str): location of group in HDF5 file to deregister

        Raises:
            TofDaqRecNotRunningError: No recording application was found
            TofDaqAcquisitionActiveError: Acquisition already active - cannot register
            TofDaqUnspecifiedError: Unspecified error
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def rds_update_source_data(self, location: str, data: npt.NDArray[np.float64]) -> None:
        """
        Updates the values for a registered data source.

        Args:
            location (str): location of group in HDF5 file identifying the user data.
            data (npt.NDArray[np.float64]): double array of length NbrElements holding the new values

        Raises:
            TofDaqRecNotRunningError: No recording application was found
            TofDaqUnspecifiedError: Unspecified error
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def rds_get_source_data(self, location: str, data: Union[npt.NDArray[np.float64], None] = None) -> npt.NDArray[np.float64]:
        """
        Reads the values for a registered data source. Use this function to access data sources that were registered by the TofDaq 
        recording application itself, other applications or through a data source plugin. Gauge pressures, TPS voltages etc.

        Args:
            location (str): location of group in HDF5 file identifying the user data
            data (Union[npt.NDArray[np.float64], None], optional): double array of length NbrElements where the data source values are copied. 
                                                                    Defaults to None - the dataset is created by this function

        Raises:
            TofDaqRecNotRunningError: No recording application was found
            FileNotFoundError: Data source specified in Location does not exist
            TofDaqUnspecifiedError: Unspecified error
            TofDaqException: Unexpected tofdaq exception

        Returns:
            npt.NDArray[np.float64]: Data array from teh RDS
        """
        pass

    @abstractmethod
    def rds_set_target(self, location: str, element: Union[str, int], value: float, block_time: int = 100) \
            -> None:
        """
        Updates the registered user element specified by its index or its label to the specified value and  
        sets the pending changes flag. The function waits for up to TW_TIMEOUT ms that the pending changes flag is currently not set, 
        then sets the specified element to the target value and toggles the flag. Then it waits up to blockTime ms for the plugin to reset the flag. 
        A registered data source that supports setting value(s) needs to meet these criteria: 
            1) last element of the data source must be labeled “pending changes flag” 
            2) each data element's label that supports setting values must end with [minValue;maxValue]. 

        Args:
            location (str): Location (“name”) of registered data source.
            element (Union[str, int]): label or index of the data source element to set
            value (float): value to set
            block_time (int, optional): time in ms waiting for the reset of the pending changes flag. Defaults to 100.

        Raises:
            TofDaqRecNotRunningError: No recording application was found
            TofDaqTimeoutError: timeout (either waiting for pending changes flag to go to 0 or waiting for confirmation after setting the value)
            TofDaqUnspecifiedError: Failure to open the registered data source specified by location or the data source does not support 
                                    setting values or the supplied value is not within the valid range
            TofDaqOutOfBoundsError: Invalid index for the RDS element
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def rds_get_target_range(self, location: str, element: Union[str, int]) -> Tuple[float, float]:
        """
        Checks that an element can be set  with pending changes flag and extracts the minimum and maximum supported value

        Args:
            location (str): Location (“name”) of registered data source.
            element (Union[str, int]): label or index of teh registered data source element

        Raises:
            TofDaqRecNotRunningError: No recording application was found
            TofDaqNoDataError: The element specified by elementIndex does not support setting its value
            TofDaqUnspecifiedError: Failure to open the registered data source specified by location
            TofDaqOutOfBoundsError: Invalid index for the RDS element
            TofDaqException: Unexpected tofdaq exception

        Returns:
            Tuple[float, float]: minimum and maximum value
        """
        pass

    @abstractmethod
    def rds_get_size(self, location: str) -> int:
        """
        Convenience function to quickly query the size of a registered data source

        Args:
            location (str): location of group in HDF5 file identifying the user data

        Raises:
            TofDaqUnspecifiedError:  invalid/nonexistent Location
            TofDaqException: Unexpected tofdaq exception

        Returns:
            int: Number of elements in the rds location
        """
        pass

    @abstractmethod
    def rds_get_desc(self, location: str) -> List[str]:
        """
        Reads the element descriptions of a registered data source

        Args:
            location (str): location of group in HDF5 file identifying the user data

        Raises:
            TofDaqRecNotRunningError: No recording application was found
            TofDaqTimeoutError: No information was retrieved within timeout
            TofDaqUnspecifiedError: Unspecified Error
            TofDaqNoDataError: No location named {location} was found in the RDS, or it has 
                               no descriptions (TwInfo) stored with
            TofDaqException: Unexpected tofdaq exception

        Returns:
            List[str]: list of element descriptions in RDS
        """
        pass

    @abstractmethod
    def rds_get_all_sources(self) -> List[RegisteredDataSource]:
        """
        Queries names, dimensions and types of all data sources currently registered in TofDaq recorder

        Raises:
            TofDaqRecNotRunningError: No recording application was found
            TofDaqTimeoutError: Timeout in interprocess communication
            TofDaqUnspecifiedError: Mismatch between the array length and the arrays
            TofDaqException: Unexpected tofdaq exception

        Returns:
            List[RegisteredDataSource]: list of objects containing information on the registered RDS
        """
        pass

    # ------------------------ TPS REMOTE CONTROL FUNCTIONS ------------------------
    @abstractmethod
    def tps_connect(self, ip: str = "localhost", tpsType: int = 1) -> None:
        """
        Connects to a local or remote TPS

        Args:
            ip (str, optional): TPS2 host name or IP. Defaults to "localhost".
            tpsType (int, optional): TPS type (0: 1st generation TPS, 1: 2nd generation TPS). Defaults to 1.

        Raises:
            TofDaqUnspecifiedError: Failed to connect
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def tps_disconnect(self) -> None:
        """
        Disconnects from a remote control enabled TPSController software.

        Raises:
            TofDaqUnspecifiedError: TPS not connected
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def tps_get_monitor_value(self, rc_code: int) -> float:
        """
        Retrieves the last reported monitor value for a given rc code.

        Args:
            rc_code (int): rc code

        Raises:
            TofDaqUnspecifiedError: TPS not connected
            TofDaqOutOfBoundsError: RC code does not exist
            TofDaqException: Unexpected tofdaq exception

        Returns:
            float: current monitor value
        """
        pass

    @abstractmethod
    def tps_get_target_value(self, rc_code: int) -> float:
        """
        Retrieves the last reported target value for a given rc code.

        Args:
            rc_code (int): rc code

        Raises:
            TofDaqUnspecifiedError: TPS not connected or RC code is not settable
            TofDaqOutOfBoundsError: RC code does not exist
            TofDaqException: Unexpected tofdaq exception

        Returns:
            float: current target value
        """
        pass

    @abstractmethod
    def tps_get_last_set_value(self, rc_code: int) -> float:
        """
        Retrieves the last reported “last set” value for a given rc code

        Args:
            rc_code (int): rc code

        Raises:
            TofDaqUnspecifiedError: TPS not connected
            TofDaqOutOfBoundsError: RC code does not exist
            TofDaqException: Unexpected tofdaq exception

        Returns:
            float: last set value
        """
        pass

    @abstractmethod
    def tps_set_target_value(self, rc_code: int, value: float) -> None:
        """
        Stes the target value for a given module.

        Args:
            rc_code (int): rc code
            value (float): set value

        Raises:
            TofDaqUnspecifiedError: TPS not connected
            TofDaqOutOfBoundsError: RC code does not exist
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def tps_get_rc_codes(self) -> List[int]:
        """
        Gets module codes of all controllable TPS modules.

        Raises:
            TofDaqUnspecifiedError: TPS not connected
            TofDaqException: Unexpected tofdaq exception

        Returns:
            List[int]: list of all available rc codes
        """
        pass

    @abstractmethod
    def tps_initialize(self) -> None:
        """
        Initializes TPS - used after a tps shutdown

        Raises:
            TofDaqUnspecifiedError: TPS not connected
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def tps_set_all_voltages(self) -> None:
        """
        Sets all voltages.

        Raises:
            TofDaqUnspecifiedError: TPS not connected
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def tps_shutdown(self) -> None:
        """
        Shuts down TPS

        Raises:
            TofDaqUnspecifiedError: TPS not connected
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def tps_get_status(self) -> TpsStatus:
        """
        Retrieves the status of the TPS.

        Raises:
            TofDaqUnspecifiedError: TPS not connected
            TofDaqException: Unexpected tofdaq exception

        Returns:
            TpsStatus: Status of the TPS
        """
        pass

    @abstractmethod
    def tps_save_set_file(self, set_file: str, set_file_type: SetFileType = SetFileType.web_gui,
                          rds_name: Union[str, None] = None) -> None:
        """
        Stores the current TPS settings to a .set file.

        Args:
            set_file (str): Path to the .set file to be created
            set_file_type (SetFileType, optional): Set file format. Defaults to SetFileType.web_gui.
            rds_name (Union[str, None], optional): name of the rds fields to include in the set file. Defaults to None.

        Raises:
            ValueError: Invalid set file type
            TofDaqUnspecifiedError: TPS not connected or no permission to write the set file
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def tps_load_set_file(self, set_file: str, rds_list: Union[List[str], None] = None,
                          rc_list: Union[None, List[int]] = None, include_rc_in_list: Union[None, bool] = None) -> None:
        """
        Loads a TPS Controller set file from disk and allows to optinally specify blacklisted or whitelisted RC codes and rds entries as well

        Args:
            set_file (str): .set file to load and set
            rds_list (Union[List[str], None], optional): list of name of rds elements to be loaded form the file as well. Defaults to None.
            rc_list (Union[None, List[int]], optional): list of rc codes to be exclueded/included in the loading procedure. Defaults to None.
            include_rc_in_list (Union[None, bool], optional): control if the rc codes specifed should be included (True) or excluded (False) 
                                                              from the loading procedure. Defaults to None.

        Raises:
            ValueError: Invalid combination of input parameters - if an rc_code list was passed, wether it is excluded or included 
                        in the loading should be specified
            TofDaqUnspecifiedError: TPS not connected or no permission to read the set file
            FileNotFoundError: The .set file does not exist
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def tps_get_rc_limits(self, rc_code: int) -> Tuple[float, float]:
        """
        Queries the (ion mode dependent) limits for a given TPS module

        Args:
            rc_code (int): rc code

        Raises:
            TofDaqUnspecifiedError: TPS not connected
            TofDaqOutOfBoundsError: RC code does not exist
            TofDaqException: Unexpected tofdaq exception

        Returns:
            Tuple[float, float]: minimum and maximum values allowed for this rc code
        """
        pass

    @abstractmethod
    def keep_file_open(self, keep_open: bool) -> None:
        """
        Allows the API user to keep the data file open at the end of an acquisition.

        Args:
            keep_open (bool): Pass true (after DAQ start) to signal to recorder to keep the data file open,
                              when done adding data issue false to allow the recorder to close the file.

        Raises:
            TofDaqRecNotRunningError - no recording application was found
            TofDaqNoActiveAcquisitionError - no active acquisition
            TofDaqTimeoutError - timeout
            FileNotFoundError - acquisition without data file detected
            TofDaqException: Unexpected tofdaq exception
        """
        pass

    @abstractmethod
    def tps_get_module_properties(self, rc_code: int) -> TpsModule:
        """
        Queries capabilities and label for a given RC code.

        Args:
            rc_code (int): rc code

        Raises:
            TofDaqUnspecifiedError: TPS not connected
            TofDaqOutOfBoundsError: RC code does not exist
            TofDaqException: Unexpected tofdaq exception

        Returns:
            TpsModule: Object with all information on the TPS module
        """
        pass

    @abstractmethod
    def tps_change_ion_mode(self, ionMode: IonMode) -> None:
        """
        Change the ion mode in the TPS.

        This function does not apply any change in the voltages, it is the user
        responsibility to zero the voltages and change polarity in a controlled and safe manner

        Args:
            ionMode: Enum with possible ion mode values

        Raises:
            TofDaqInvalidValueError: Invalid Ion Mode passed - the TPS cannot be set to this mode
        """
        pass

    # @abstractmethod
    # def on_demand_mass_calibration(self, action: int) -> None:
    #     pass
    #
    # @abstractmethod
    # def saturation_warning(self) -> bool:
    #     pass
    #
    # @abstractmethod
    # def tps_get_nmt_state(self, rc_code: int) -> NmtStatus:
    #     #is this in use?
    #     pass
    #
    # @abstractmethod
    # def tps_set_nmt_cmd(self, rc_code: int, nmt_cmd: NmtCommand) -> None:
    #     #is this in use
    #     pass
    #
    # @abstractmethod
    # def tps_configure_for_single_ion_measurement(self, nbr_bits: npt.NDArray[np.int32],
    #                                              negativeSignal: npt.NDArray[np.int8]) -> None:
    #     #what are the argumebts and the use of this function? is not mentioned in the wiki
    #     pass
    #
    # @abstractmethod
    # def tps_send_pdo(self, cobId: int, data: str) -> None:
    #     #what is the use for this function?
    #     pass
