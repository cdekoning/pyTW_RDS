"""
Sub-module with custom exceptions that can be raised by TofDaqRec
"""
from enum import Enum

class TofDaqException(Exception):
    """General exception thrown by the TofDaqDll"""

    def __init__(self, rv: int, message: str = ""):
        self.message = message
        self.rv = rv
        super().__init__(self.message)


class TofDaqRecNotRunningError(TofDaqException):
    """Exception thrown when the recorder is not running"""

    def __init__(self, rv: int, message=""):
        super().__init__(rv = rv, message = message)


class TofDaqAcquisitionActiveError(TofDaqException):
    """Exception thrown when the acquisition is already active"""

    def __init__(self,  rv: int, message=""):
        super().__init__(rv = rv, message = message)


class TofDaqNoActiveAcquisitionError(TofDaqException):
    """Exception thrown when the acquisition is not active"""

    def __init__(self,  rv: int, message=""):
        self.message = message
        super().__init__(rv = rv, message = message)


class TofDaqUnspecifiedError(TofDaqException):
    """Exception thrown when an unspecified tofdaq error is encountered"""

    def __init__(self,  rv: int, message=""):
        self.message = message
        super().__init__(rv = rv, message=message)


class TofDaqOutOfBoundsError(TofDaqException):
    """
    Exception thrown  in three cases:
     - The value of a parameter being set is invalid or outside the allowed bounds
     - An array was being accessed at an invalid index
     - There is a size mismatch between an array passed by reference and its length, passed as a separate argument
     """

    def __init__(self,  rv: int, message=""):
        self.message = message
        super().__init__(rv = rv, message=message)


class TofDaqNoDataError(TofDaqException):
    """Exception thrown in different scenarios depending on e function - details on the origin should be passed to the
    message parameter"""

    def __init__(self,  rv: int, message=""):
        self.message = message
        super().__init__(rv = rv, message=message)


class TofDaqTimeoutError(TofDaqException):
    """Exception thrown after an API call to TofDaq timed out"""

    def __init__(self,  rv: int, message=""):
        self.message = message
        super().__init__(rv = rv, message=message)


class TofDaqValueAdjustedWarning(TofDaqException):
    """Exception thrown when an API call adjusts an input (e.g: the length of an array) or when an operation is
    succeeded for only a subset of the elements"""

    def __init__(self,  rv: int, message=""):
        self.message = message
        super().__init__(rv = rv, message=message)


class TofDaqInvalidParameterError(TofDaqException):
    """Exception thrown when a parameter passed to an APi call is invalid"""

    def __init__(self,  rv: int, message=""):
        self.message = message
        super().__init__(rv = rv, message=message)


class TofDaqInvalidValueError(TofDaqException):
    """Exception thrown when the value passed to a parameter in the API call is invalid"""

    def __init__(self,  rv: int, message=""):
        self.message = message
        super().__init__(rv = rv, message=message)


class TofDaqAbortedError(TofDaqException):
    """Exception thrown when an API call was aborted"""

    def __init__(self,  rv: int, message=""):
        self.message = message
        super().__init__(rv = rv, message=message)


class TofDaqWrongPolarity(TofDaqException):
    """Exception thrown when an API call was aborted"""

    def __init__(self,  rv: int, message=""):
        super().__init__(rv = rv, message=message)


class TwRetVal(Enum):
    TwDaqRecNotRunning = 0
    TwAcquisitionActive = 1
    TwNoActiveAcquisition = 2
    TwFileNotFound = 3
    TwSuccess = 4
    TwError = 5
    TwOutOfBounds = 6
    TwNoData = 7
    TwTimeout = 8
    TwValueAdjusted = 9
    TwInvalidParameter = 10
    TwInvalidValue = 11
    TwAborted = 12
    TwWrongPolarity = 13
