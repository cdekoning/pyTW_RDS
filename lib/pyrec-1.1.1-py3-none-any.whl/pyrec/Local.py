"""
Sub-Module containing the class modeling a local TofDaqRec instance with its methods, wrapping the TofDaqDll in a
pythonic way.
"""
import copy
import ast
from datetime import datetime, timedelta
from time import altzone, daylight, timezone
import logging
from typing import Union, List, Tuple
import ctypes as ct
import numpy as np
import numpy.typing as npt
import sys
from pathlib import Path
import shutil

sys.path.append(str(Path(__file__).absolute().parent.parent))
from pyrec.TofDaqRec import TofDaqRec

from pyrec.DataStructures import TpsModule, IonMode, TpsStatus, RegisteredDataSource, \
    RegisteredDataType, MassSpectrumData, MassCalibrationData, SharedMemoryDesc, PeakPar, TpsModuleProperties, \
    ReturnType, SetFileType, SegmentProfileData, DioState, ConfigWindow
from pyrec.DaqExceptions import (TwRetVal, TofDaqRecNotRunningError, TofDaqNoDataError,
                                 TofDaqValueAdjustedWarning,
                                 TofDaqTimeoutError, TofDaqUnspecifiedError,
                                 TofDaqInvalidValueError, TofDaqInvalidParameterError, TofDaqOutOfBoundsError,
                                 TofDaqAcquisitionActiveError, TofDaqNoActiveAcquisitionError, TofDaqException)

from pytofdaq import TofDaq as td
from pytofdaq import TwTool as tt
from pytofdaq import TwH5 as th

logger = logging.getLogger(__name__)
FILETIME_epoch = datetime(1601, 1, 1) - timedelta(seconds=altzone if daylight else timezone)


class TofDaqRecLocal(TofDaqRec):
    """
    Local instance of TofDaqRec, high level wrapper ot the TofDaqDll
    """
    def __init__(self):
        self.tofdaq_dll_rev = int(1.0E6 * (self.get_dll_version() - 1.99) + 0.5)

    def get_dll_version(self) -> float:
        return td.TwGetDllVersion()

    def initialize_dll(self) -> None:
        rv = TwRetVal(td.TwInitializeDll())
        if rv == TwRetVal.TwSuccess:
            logger.info("TofDaqDll successfully initialized")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "Initialization failed")
        else:
            raise TofDaqException(rv.value)

    def cleanup_dll(self) -> None:
        td.TwCleanupDll()

    def is_tofdaq_running(self) -> bool:
        return td.TwTofDaqRunning()

    def is_acquisition_active(self) -> bool:
        return td.TwDaqActive()

    def start_acquisition(self) -> None:
        timeout_orig = self.get_timeout()
        self.set_timeout(30000)
        rv = TwRetVal(td.TwStartAcquisition())
        self.set_timeout(timeout_orig)
        if rv == TwRetVal.TwSuccess:
            logger.info("Acquisition Started")
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwAcquisitionActive:
            logger.info("The acquisition is already active - will not be restarted")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, f"No successful start was confirmed within {self.get_timeout()} ms")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "Event abandoned or untreated error")
        else:
            raise TofDaqException(rv.value)

    def stop_acquisition(self) -> None:
        timeout_orig = self.get_timeout()
        self.set_timeout(30000)
        rv = TwRetVal(td.TwStopAcquisition())
        self.set_timeout(timeout_orig)
        if rv == TwRetVal.TwSuccess:
            logger.info("Acquisition Stopped")
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoActiveAcquisition:
            logger.info("The acquisition has already been stopped")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, f"No successful stop was confirmed within {self.get_timeout()} ms")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "Event abandoned or untreated error")
        else:
            raise TofDaqException(rv.value)

    def continue_acquisition(self) -> None:
        timeout_orig = self.get_timeout()
        self.set_timeout(30000)
        rv = TwRetVal(td.TwContinueAcquisition())
        self.set_timeout(timeout_orig)
        if rv == TwRetVal.TwSuccess:
            logger.info("Acquisition Continuing")
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoActiveAcquisition:
            raise TofDaqNoActiveAcquisitionError(rv.value, "No active acquisition to continue")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, f"No successful continue was confirmed within {self.get_timeout()} ms")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "TofDaqRec does not expect a continue signal")
        else:
            raise TofDaqException(rv.value)

    def manual_continue_needed(self) -> bool:
        return td.TwManualContinueNeeded()

    def close_tofdaq_rec(self) -> None:
        timeout_orig = self.get_timeout()
        self.set_timeout(30000)
        rv = TwRetVal(td.TwCloseTofDaqRec())
        self.set_timeout(timeout_orig)

        if rv == TwRetVal.TwSuccess:
            logger.info("TofDaqRec was successfully shutdown")
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, f"No successful shutdown was confirmed within {self.get_timeout()} ms")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value)
        else:
            raise TofDaqException(rv.value)

    def recorder_needs_restart(self) -> bool:
        return td.TwRecorderNeedsRestart()

    def set_timeout(self, timeout: int) -> None:
        td.TwSetTimeout(timeout=timeout)

    def get_timeout(self) -> int:
        return td.TwGetTimeout()

    def auto_setup_daq_device(self) -> None:

        rv = TwRetVal(td.TwAutoSetupDaqDevice())

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwAcquisitionActive:
            raise TofDaqAcquisitionActiveError(rv.value, "Active acquisition")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, "No confirmation of successful setup received within 10 seconds")
        else:
            raise TofDaqException(rv.value)

    def initialize_daq_device(self) -> None:

        rv = TwRetVal(td.TwInitializeDaqDevice())

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwAcquisitionActive:
            raise TofDaqAcquisitionActiveError(rv.value, "Active acquisition")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, "No confirmation of successful setup received within 8 seconds")
        else:
            raise TofDaqException(rv.value)

    def issue_dio4_pulse(self, delay: int, width: int) -> None:

        rv = TwRetVal(td.TwIssueDio4Pulse(delay=delay, width=width))

        if rv == TwRetVal.TwSuccess:
          pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoActiveAcquisition:
            raise TofDaqNoActiveAcquisitionError(rv.value, "No active acquisition")
        elif rv == TwRetVal.TwOutOfBounds:
            raise TofDaqOutOfBoundsError(rv.value, f"Invalid parameters - either delay ({delay}) or width({width}) < 0")
        else:
            raise TofDaqException(rv.value)

    def set_dio4_state(self, state: DioState) -> None:

        rv = TwRetVal(td.TwSetDio4State(state=state.value))

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoActiveAcquisition:
            raise TofDaqNoActiveAcquisitionError(rv.value, "No active acquisition")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "unable to access digital line")
        else:
            raise TofDaqException(rv.value)

    def waiting_for_dio_start_signal(self) -> bool:
        return td.TwWaitingForDioStartSignal()

    def send_dio_start_signal(self) -> None:

        rv = TwRetVal(td.TwSendDioStartSignal())
        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoActiveAcquisition:
            raise TofDaqNoActiveAcquisitionError(rv.value, "No active acquisition")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "see debug output")
        else:
            raise TofDaqException(rv.value)

    def is_dio_start_delay_active(self) -> bool:

        return td.TwDioStartDelayActive()

    def move_last_acquisition_datafiles(self, destination_path: Union[str, Path] = Path(".")) -> None:
        if isinstance(destination_path, str):
            destination_path = Path(destination_path)

        file_path = self.get_daq_parameter('DataPath')
        files = Path(file_path).glob("*.h5")
        sorted_files = sorted([f for f in files], key=lambda item: item.stat().st_ctime, reverse=True)
        location = '/'
        run_nbr = np.empty(shape=(1,), dtype=np.int32)

        rv = th.TwGetIntAttributeFromH5(str(sorted_files[0]).encode(), location.encode(), 'CurrentRun'.encode(),
                                        run_nbr)

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwFileNotFound:
            raise FileNotFoundError(rv.value, f"The data file {sorted_files[0]} was not found (or access denied)")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value,
                                         f"The attribute 'CurrentRun' is NULL or the attribute name not found at "
                                         f"location {location}")

        rv = th.TwCloseH5(str(sorted_files[0]).encode())
        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwFileNotFound:
            raise FileNotFoundError(rv.value, f"The data file {sorted_files[0]} was not found (or access denied)")

        if run_nbr[0] == 1:
            shutil.move(sorted_files[0], destination_path)
        else:
            while run_nbr[0] > 1:
                file = sorted_files.pop(0)
                shutil.move(file, destination_path)
                run_nbr = np.empty(shape=(1,), dtype=np.int32)

                rv = th.TwGetIntAttributeFromH5(str(sorted_files[0]).encode(), location.encode(), 'CurrentRun'.encode(),
                                                run_nbr)
                if rv == TwRetVal.TwSuccess:
                    pass
                elif rv == TwRetVal.TwFileNotFound:
                    raise FileNotFoundError(rv.value,
                                            f"The data file {sorted_files[0]} was not found (or access denied)")
                elif rv == TwRetVal.TwError:
                    raise TofDaqUnspecifiedError(rv.value,
                                                 f"The attribute 'CurrentRun' is NULL or the attribute name not found at "
                                                 f"location {location}")

                rv = th.TwCloseH5(str(sorted_files[0]).encode())
                if rv == TwRetVal.TwSuccess:
                    pass
                elif rv == TwRetVal.TwFileNotFound:
                    raise FileNotFoundError(rv.value,
                                            f"The data file {sorted_files[0]} was not found (or access denied)")

            shutil.move(sorted_files[0], destination_path)

    def show_config_window(self, config_window_tab: ConfigWindow = ConfigWindow.daq_tab) -> None:

        rv = TwRetVal(td.TwShowConfigWindow(config_window_tab.value))

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value)
        else:
            raise TofDaqException(rv.value)

    def load_ini_file(self, ini_filename: Union[str, None] = None) -> None:
        
        if ini_filename is not None:
            rv = TwRetVal(td.TwLoadIniFile(iniFilename=ini_filename.encode('l1')))
        else:
            ini_filename = ""
            rv = TwRetVal(td.TwLoadIniFile(iniFilename="".encode('l1')))

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwAcquisitionActive:
            raise TofDaqAcquisitionActiveError(rv.value, "Acquisition already active")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, f"No successful file load was confirmed within {self.get_timeout()} ms")
        elif rv == TwRetVal.TwFileNotFound:
            raise FileNotFoundError(rv.value, f"The specified configuration file {ini_filename} could not be found")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, f"The specified configuration file is too long (>255 char)")
        else:
            raise TofDaqException(rv.value)

    def save_ini_file(self, ini_filename: Union[str, None] = None) -> None:
        
        if ini_filename is not None:
            rv = TwRetVal(td.TwSaveIniFile(iniFilename=ini_filename.encode('l1')))
        else:
            ini_filename = ""
            rv = TwRetVal(td.TwSaveIniFile(iniFilename="".encode('l1')))

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwAcquisitionActive:
            raise TofDaqAcquisitionActiveError(rv.value, "Acquisition already active")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, f"No successful file load was confirmed within {self.get_timeout()} ms")
        elif rv == TwRetVal.TwFileNotFound:
            raise FileNotFoundError(rv.value,
                f"The path specified in IniFile - {ini_filename} - does not exist or no permission to create file")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, f"The specified configuration file is too long (>255 char)")
        else:
            raise TofDaqException(rv.value)

    def get_daq_parameter(self, parameter: str) -> Union[str, int, bool, float]:

        parameter_c = parameter.encode('l1')

        value = td.TwGetDaqParameter(parameter_c)
        try:
            return ast.literal_eval(value.decode('l1'))
        except:
            try:
                return ast.literal_eval(value.decode('l1').capitalize())
            except:
                return value.decode('l1')

    def set_daq_parameter(self, parameter: str, value: Union[str, int, bool, float], auto_adjust_value: bool = True) \
            -> Union[str, int, bool, float]:
        
        parameter_c = parameter.encode('l1')

        if isinstance(value, str):
            input_value = copy.deepcopy(value.encode('l1'))
            rv = TwRetVal(td.TwSetDaqParameter(parameter_c, input_value))
            if rv == TwRetVal.TwValueAdjusted:
                set_value = self.get_daq_parameter(parameter)
                logger.warning(f"The value for {parameter} was adjusted from {input_value} to {set_value}")
            else:
                set_value = input_value
        elif isinstance(value, bool):
            input_value = value
            rv = TwRetVal(td.TwSetDaqParameterBool(parameter_c, input_value))
            if rv == TwRetVal.TwValueAdjusted:
                set_value = self.get_daq_parameter(parameter)
                logger.warning(f"The value for {parameter} was adjusted from {input_value} to {set_value}")
            else:
                set_value = input_value
        elif isinstance(value, int):
            input_value = np.int32(value)
            rv = TwRetVal(td.TwSetDaqParameterInt(parameter_c, input_value))
            if rv == TwRetVal.TwInvalidValue:
                input_value = np.int64(value)
                rv = TwRetVal(td.TwSetDaqParameterInt64(parameter_c, input_value))
                if rv == TwRetVal.TwValueAdjusted:
                    set_value = self.get_daq_parameter(parameter)
                    logger.warning(f"The value for {parameter} was adjusted from {input_value} to {set_value}")
                else:
                    set_value = input_value
            elif rv == TwRetVal.TwValueAdjusted:
                set_value = self.get_daq_parameter(parameter)
                logger.warning(f"The value for {parameter} was adjusted from {input_value} to {set_value}")
            else:
                set_value = input_value
        elif isinstance(value, float):
            input_value = np.float32(value)
            rv = TwRetVal(td.TwSetDaqParameterFloat(parameter_c, input_value))
            if rv == TwRetVal.TwInvalidValue:
                input_value = np.float64(value)
                rv = TwRetVal(td.TwSetDaqParameterDouble(parameter_c, input_value))
                if rv == TwRetVal.TwValueAdjusted:
                    set_value = self.get_daq_parameter(parameter)
                    logger.warning(f"The value for {parameter} was adjusted from {input_value} to {set_value}")
                else:
                    set_value = input_value
            elif rv == TwRetVal.TwValueAdjusted:
                set_value = self.get_daq_parameter(parameter)
                logger.warning(f"The value for {parameter} was adjusted from {input_value} to {set_value}")
            else:
                set_value = input_value
        else:
            raise TypeError(f"Invalid type {type(value)} for the specified Daq parameter - {parameter}")

        if rv == TwRetVal.TwSuccess:
            return set_value
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwAcquisitionActive:
            raise TofDaqAcquisitionActiveError(rv.value, "Acquisition already active")
        elif rv == TwRetVal.TwInvalidParameter:
            raise TofDaqInvalidParameterError(rv.value, "Unknown parameter")
        elif rv == TwRetVal.TwInvalidValue:
            raise TofDaqInvalidValueError(rv.value, f"Value type not compatible with parameter")
        elif rv == TwRetVal.TwValueAdjusted:
            if not auto_adjust_value:
                raise TofDaqValueAdjustedWarning(rv.value, f"The value could not be set as it should have been adjusted from "
                                                 f"{value} to {set_value}")
            else:
                logger.warning(f"The parameter {parameter} was successfully updated in TofDaqRec, but the set value was "
                           f"adjusted from {value} to {set_value}")
                return set_value
        else:
            raise TofDaqException(rv.value)

    def get_descriptor(self) -> SharedMemoryDesc:
        
        desc = td.TSharedMemoryDesc()
        rv = TwRetVal(td.TwGetDescriptor(desc))

        if rv == TwRetVal.TwSuccess:
            return SharedMemoryDesc(desc)
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "Untreated error")
        else:
            raise TofDaqException(rv.value)

    def get_peak_parameters(self, peak_index: int) -> PeakPar:
        
        peak_par = td.TPeakPar()
        rv = TwRetVal(td.TwGetPeakParameters(peak_index, peak_par))

        if rv == TwRetVal.TwSuccess:
            return PeakPar(peak_par)
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "Untreated error")
        elif rv == TwRetVal.TwOutOfBounds:
            raise TofDaqOutOfBoundsError(rv.value, "The peak index is not in range")
        else:
            raise TofDaqException(rv.value)

    def wait_for_new_data(self, timeout: int = 250, wait_for_event_reset: bool = True) -> SharedMemoryDesc:

        desc = td.TSharedMemoryDesc()
        rv = TwRetVal(td.TwWaitForNewData(Timeout=timeout, ShMemDescriptor=desc, ShMem=None, WaitForEventReset=True))

        if rv == TwRetVal.TwSuccess:
            return SharedMemoryDesc(desc)
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "Memory mapping failed")
        elif rv == TwRetVal.TwNoData:
            raise TofDaqNoDataError(rv.value, "No data is recorded or memory not yet allocated")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, f"No new data available during {timeout} ms")
        else:
            raise TofDaqException(rv.value)

    def wait_for_end_of_acquisition(self, timeout: int) -> None:
        
        rv = td.TwWaitForEndOfAcquisition(timeout)
        if rv == TwRetVal.TwSuccess:
            return
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoActiveAcquisition:
            raise TofDaqNoActiveAcquisitionError(rv.value, "No active acquisition")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, f"No new data available during {timeout} ms")
        else:
            raise TofDaqException(rv.value)

    def get_mass_calibration(self, segment_index: int = 0, buf_index: int = 0) \
            -> MassCalibrationData:
        
        # mode_c = np.ones(1, dtype=np.int32) * mode
        mode_c = np.empty(1, dtype=np.int32)
        mc_nbr_par = np.zeros(1, dtype=np.int32)
        mc_nbr_points = np.zeros(1, dtype=np.int32)
        rv1 = TwRetVal(td.TwGetMassCalibFromShMem(mode_c, mc_nbr_par, None, mc_nbr_points, None, None,
                                                  None, None, None, segment_index, buf_index))
        if rv1 == TwRetVal.TwSuccess:
            pass
        elif rv1 == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv1.value, "No recording application was found")
        elif rv1 == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv1.value, f"No mass calibration data retrieved after {self.get_timeout()} ms")
        elif rv1 == TwRetVal.TwValueAdjusted:
            pass
        else:
            raise TofDaqException(rv1.value)

        p = np.zeros((mc_nbr_par[0],), dtype=np.float64)
        mass = np.zeros((mc_nbr_points[0],), dtype=np.float64)
        tof = np.zeros((mc_nbr_points[0],), dtype=np.float64)
        weight = np.zeros((mc_nbr_points[0],), dtype=np.float64)
        label_c = ct.create_string_buffer(int(mc_nbr_points[0] * 256))
        sis = np.zeros((1,), dtype=np.float64)

        rv = TwRetVal(td.TwGetMassCalibFromShMem(mode=mode_c, nbrParams=mc_nbr_par, p=p, nbrPoints=mc_nbr_points,
                                                 mass=mass, tof=tof, weight=weight, label=label_c, sis=sis,
                                                 segmentIndex=segment_index, bufIndex=buf_index))
        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, f"No mass calibration data retrieved after {self.get_timeout()} ms")
        else:
            raise TofDaqException(rv.value)

        label = []
        nbr_strings = int(len(label_c) / 256)
        for idx in range(0, nbr_strings):
            start = idx * 256
            label.append(label_c[start:start + 256].decode('l1').strip("\x00"))

        return MassCalibrationData(label=label, p=p, mass=mass, tof=tof, weight=weight, sis=sis, mode=int(mode_c[0]),
                                   nbr_points=int(mc_nbr_points[0]))

    def set_mass_calibration(self, mass_cal: MassCalibrationData, segment_index: int = 0, buf_index: int = 0) -> None:
       
        mode = mass_cal.mode
        mc_nbr_par = len(mass_cal.p)
        mc_nbr_points = len(mass_cal.mass)
        p = mass_cal.p
        mass = mass_cal.mass
        tof = mass_cal.tof
        weight = mass_cal.weight
        sis = mass_cal.sis

        label = mass_cal.label
        label_c = ct.create_string_buffer(len(mass_cal.mass) * 256)
        for idx, l in enumerate(label):
            start = idx * 256
            label_c[start:start + 256] = l.encode('l1') + bytes(256 - len(l))

        rv = TwRetVal(td.TwSetMassCalibInShMem(mode=mode, nbrParams=mc_nbr_par, p=p, nbrPoints=mc_nbr_points,
                                               mass=mass, tof=tof, weight=weight, label=label_c, sis=sis,
                                               segmentIndex=segment_index, bufIndex=buf_index))

        if rv == TwRetVal.TwSuccess:
            logger.debug(f"Mass Calibration successfully set for segment {segment_index} and buffer{buf_index}")
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, f"No mass calibration data could be set in {self.get_timeout()} ms")
        elif rv == TwRetVal.TwAcquisitionActive:
            raise TofDaqAcquisitionActiveError(rv.value, "Acquisition already active")
        else:
            raise TofDaqException(rv.value)

    def get_sum_spectrum(self, spectrum: Union[npt.NDArray[np.float64], None] = None, normalize: bool = True,
                         return_type: ReturnType = ReturnType.spectrum) -> MassSpectrumData:

        desc = self.get_descriptor()
        if spectrum is None:
            spectrum = np.empty(shape=(desc.nbr_samples,), dtype=np.float64)
        if normalize == True:
            unit = "[counts/extr.]"
        else:
            unit = "[counts]"

        rv = TwRetVal(td.TwGetSumSpectrumFromShMem(spectrum=spectrum, normalize=normalize))

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoData:
            raise TofDaqNoDataError(rv.value, f"Sum spectrum data not available")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value)
        else:
            raise TofDaqException(rv.value)

        result = MassSpectrumData(desc.nbr_samples)
        if return_type == ReturnType.array:
            result.spectrum = spectrum
            result.spectrum_units = unit
        elif return_type == ReturnType.spectrum:
            last_buf_index_shm = (desc.total_bufs_processed - 1) % desc.nbr_bufs
            last_write_index_shm = (desc.total_bufs_processed - 1) // desc.nbr_bufs
            prev_buf_index_shm = (desc.total_bufs_processed - desc.nbr_bufs - 1) % desc.nbr_bufs
            prev_write_index_shm = (desc.total_bufs_processed - desc.nbr_bufs - 1) // desc.nbr_bufs
            ms = self.get_tof_spectrum(start_segment=0, end_segment=desc.nbr_segments - 1, buf_index=last_buf_index_shm,
                                       return_type=ReturnType.spectrum)
            result.spectrum = spectrum
            result.spectrum_units = unit
            result.x_axis = ms.x_axis
            result.x_axis_units = ms.x_axis_units
            start_time_buf = desc.time_zero + self.get_spec_time(last_buf_index_shm, last_write_index_shm) * 1e7
            end_time_buf = start_time_buf + (start_time_buf - desc.time_zero -
                                             self.get_spec_time(prev_buf_index_shm,
                                                                prev_write_index_shm) * 1e7) / desc.nbr_bufs
            result.time = (FILETIME_epoch + timedelta(microseconds=start_time_buf // 10),
                           FILETIME_epoch + timedelta(microseconds=end_time_buf // 10))
        else:
            raise ValueError(f"Invalid return type {return_type}")

        return result

    def get_tof_spectrum(self, spectrum: Union[npt.NDArray[np.float32], None] = None, start_segment: int = 0,
                         end_segment: int = 0, buf_index: int = -1, normalize: bool = True,
                         return_type: ReturnType = ReturnType.spectrum) -> MassSpectrumData:
        
        if start_segment == -1:
            if end_segment == -1:
                if normalize == True:
                    normalize = False
                    logger.warning("When the spectra from all segments are returned concatenated, no normalization can be "
                                   "applied. The returned unit is switched to counts")
                if spectrum is None:
                    desc = self.get_descriptor()
                    spectrum = np.empty(shape=(desc.nbr_samples * desc.nbr_segments,), dtype=np.float32)
            else:
                raise TofDaqInvalidValueError(rv=11, message="If start_segment=-1, must be that also end_segment=-1")
        elif end_segment == -1:
            raise TofDaqInvalidValueError(rv=11, message="If end_segment=-1, mst be that also start_segment=-1")

        if spectrum is None:
            desc = self.get_descriptor()
            spectrum = np.empty(shape=(desc.nbr_samples,), dtype=np.float32)

        desc = self.get_descriptor()
        if buf_index == -1:
            buf_index = (desc.total_bufs_processed - 1) % desc.nbr_bufs

        if normalize == True:
            unit = "[counts/extr.]"
        else:
            unit = "[counts]"

        rv = TwRetVal(td.TwGetTofSpectrumFromShMem(spectrum=spectrum, normalize=normalize, segmentIndex=start_segment,
                                                   segmentEndIndex=end_segment, bufIndex=buf_index))
        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoData:
            raise TofDaqNoDataError(rv.value, "Tof spectrum data not available")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value)
        elif rv == TwRetVal.TwOutOfBounds:
            raise TofDaqOutOfBoundsError(rv.value, "At least one of the indices is out of valid range")
        else:
            raise TofDaqException(rv.value)

        result = MassSpectrumData()
        result.spectrum = spectrum
        result.spectrum_units = unit
        if return_type == ReturnType.spectrum:
            mass_axis, units = self.get_mass_axis(start_segment=start_segment, end_segment=end_segment, buf_index=buf_index)
            result.x_axis = mass_axis
            result.x_axis_units = units
            last_write_index_shm = (desc.total_bufs_processed - 1) // desc.nbr_bufs
            prev_write_index_shm = (desc.total_bufs_processed - desc.nbr_bufs - 1) // desc.nbr_bufs
            start_time_buf = desc.time_zero + self.get_spec_time(buf_index, last_write_index_shm)*1e7
            end_time_buf = start_time_buf + (start_time_buf - desc.time_zero -
                                             self.get_spec_time(buf_index, prev_write_index_shm)*1e7) / desc.nbr_bufs
            result.time = (FILETIME_epoch + timedelta(microseconds=start_time_buf//10),
                           FILETIME_epoch + timedelta(microseconds=end_time_buf//10))

        return result

    def get_mass_axis(self, specAxis: Union[npt.NDArray[np.float64], None] = None, start_segment: int = -1,
                      end_segment: int = -1, buf_index: int = -1) -> Tuple[npt.NDArray[np.float64], str]:
        
        desc = self.get_descriptor()
        if start_segment == -1:
            start_segment = 0
        if end_segment == -1:
            end_segment = desc.nbr_segments - 1
        if buf_index == -1:
            buf_index = (desc.total_bufs_processed - 1) % desc.nbr_bufs
        if specAxis is None:
            x_axis = np.empty(shape=(desc.nbr_samples,), dtype=np.float64)
        else:
            x_axis = specAxis
        segments = range(start_segment, end_segment+1)

        mc = self.get_mass_calibration(segment_index=start_segment, buf_index=buf_index)
        p = np.empty(shape=(len(segments), len(mc.p)), dtype=np.float64)
        for idx, segment in enumerate(segments):
            mc = self.get_mass_calibration(segment_index=segment, buf_index=buf_index)
            p[idx, :] = mc.p

        p_mean = np.mean(p, axis=0)
        rv = TwRetVal(tt.TwMakeMqAxis(x_axis, mc.mode, p_mean))

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value)
        else:
            raise TofDaqException(rv.value)

        return x_axis, "m/Q [Th]"

    def get_stick_spectrum(self, stick_spectrum: Union[npt.NDArray[np.float32], None] = None,
                           masses: Union[npt.NDArray[np.float32], None] = None, start_segment: int = -1,
                           end_segment: int = -1, buf_index: int = -1,
                           return_type: ReturnType = ReturnType.spectrum) -> MassSpectrumData:

        desc = self.get_descriptor()
        if start_segment == -1:
            start_segment = 0
        if end_segment == -1:
            end_segment = desc.nbr_segments - 1
        if stick_spectrum is None:
            stick_spectrum = np.empty(shape=(desc.nbr_peaks,), dtype=np.float32)
        if masses is None:
            masses = np.empty(shape=(desc.nbr_peaks,), dtype=np.float32)
        if buf_index == -1:
            buf_index = (desc.total_bufs_processed - 1) % desc.nbr_bufs

        rv = TwRetVal(td.TwGetStickSpectrumFromShMem(stick_spectrum, masses, start_segment, end_segment, buf_index))

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoData:
            raise TofDaqNoDataError(rv.value, "Tof spectrum data not available")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value)
        elif rv == TwRetVal.TwOutOfBounds:
            raise TofDaqOutOfBoundsError(rv.value, "At least one of the indices is out of valid range")
        else:
            raise TofDaqException(rv.value)

        result = MassSpectrumData()
        result.spectrum = stick_spectrum
        result.spectrum_units = "[counts]"
        if return_type == ReturnType.spectrum:
            result.x_axis = masses
            result.x_axis_units = "m/Q [Th]"
            last_write_index_shm = (desc.total_bufs_processed - 1) // desc.nbr_bufs
            prev_write_index_shm = (desc.total_bufs_processed - desc.nbr_bufs - 1) // desc.nbr_bufs
            start_time_buf = desc.time_zero + self.get_spec_time(buf_index, last_write_index_shm) * 1e7
            end_time_buf = start_time_buf + (start_time_buf - desc.time_zero -
                                             self.get_spec_time(buf_index, prev_write_index_shm) * 1e7) / desc.nbr_bufs
            result.time = (FILETIME_epoch + timedelta(microseconds=start_time_buf // 10),
                           FILETIME_epoch + timedelta(microseconds=end_time_buf // 10))

        return result

    def get_segment_profile(self, segment_profile: Union[npt.NDArray[np.float32], None] = None,
                            peak_index: Union[List[int], int] = -1, buf_index: int = -1) -> List[SegmentProfileData]:
        
        desc = self.get_descriptor()
        if buf_index == -1:
            buf_index = (desc.total_bufs_processed - 1) % desc.nbr_bufs
        if segment_profile is None and peak_index == -1:
            profile = np.empty(shape=(desc.nbr_segments * desc.nbr_peaks,), dtype=np.float32)
        elif segment_profile is None and isinstance(peak_index, list):
            profile = np.empty(shape=(desc.nbr_segments * len(peak_index),), dtype=np.float32)
        elif segment_profile is None and isinstance(peak_index, int):
            profile = np.empty(shape=(desc.nbr_segments,), dtype=np.float32)
        else:
            profile = segment_profile

        if isinstance(peak_index, list):
            for i, pidx in enumerate(peak_index):
                rv = TwRetVal(td.TwGetSegmentProfileFromShMem(
                    profile[0 + desc.nbr_segments * i: desc.nbr_segments + desc.nbr_segments*i], pidx, buf_index))

                if rv == TwRetVal.TwSuccess:
                    pass
                elif rv == TwRetVal.TwDaqRecNotRunning:
                    raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
                elif rv == TwRetVal.TwNoData:
                    raise TofDaqNoDataError(rv.value, f"Data not available for peak index {pidx}")
                elif rv == TwRetVal.TwError:
                    raise TofDaqUnspecifiedError(rv.value)
                elif rv == TwRetVal.TwOutOfBounds:
                    raise TofDaqOutOfBoundsError(rv.value, f"At least one of the indices is out of valid range "
                                                           f"for peak index {pidx}")
                else:
                    raise TofDaqException(rv.value)
        else:
            rv = TwRetVal(td.TwGetSegmentProfileFromShMem(profile, peak_index, buf_index))

            if rv == TwRetVal.TwSuccess:
                pass
            elif rv == TwRetVal.TwDaqRecNotRunning:
                raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
            elif rv == TwRetVal.TwNoData:
                raise TofDaqNoDataError(rv.value, f"Data not available")
            elif rv == TwRetVal.TwError:
                raise TofDaqUnspecifiedError(rv.value)
            elif rv == TwRetVal.TwOutOfBounds:
                raise TofDaqOutOfBoundsError(rv.value, f"At least one of the indices is out of valid range")
            else:
                raise TofDaqException(rv.value)

        profiles = []
        if peak_index == -1:
            peak_list = range(0, desc.nbr_peaks)
            seg_profiles = profile.reshape(desc.nbr_segments, desc.nbr_peaks).transpose()
        elif isinstance(peak_index, int):
            peak_list = [peak_index]
            seg_profiles = profile.reshape(1, desc.nbr_segments)
        elif isinstance(peak_index, list):
            peak_list = peak_index
            seg_profiles = profile.reshape(len(peak_index), desc.nbr_segments)
        else:
            raise TypeError

        for idx, peak_idx in enumerate(peak_list):
            peak_label = self.get_peak_parameters(peak_idx)
            profiles.append(SegmentProfileData(peak_label=peak_label.label, profile=seg_profiles[idx, :],
                                               profile_unit="[counts/extr.]"))
        return profiles

    def get_spec_time(self, buf_index: int = 0, write_index: int = -1) -> float:
        
        desc = self.get_descriptor()
        if write_index == -1:
            write_index = desc.i_write
        time = np.empty(shape=(1,), dtype=np.float64)
        rv = TwRetVal(td.TwGetBufTimeFromShMem(time, bufIndex=buf_index, writeIndex=write_index))

        if rv == TwRetVal.TwSuccess:
            return float(time[0])
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoData:
            raise TofDaqNoDataError(rv.value, "Time data not available")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value)
        elif rv == TwRetVal.TwOutOfBounds:
            raise TofDaqOutOfBoundsError(rv.value, "At least one of the indices is out of valid range")
        else:
            raise TofDaqException(rv.value)

    def store_file(self, file_location: str, vfs_location: str) -> None:

        file_location_c = file_location.encode('l1')
        vfs_location_c = vfs_location.encode('l1')
        rv = TwRetVal(td.TwStoreFile(file_location_c, vfs_location_c))

        if rv == TwRetVal.TwSuccess:
            pass
        else:
            raise TofDaqException(rv.value)

    def add_log_entry(self, log_entry: str, log_entry_time: Union[datetime, int] = 0) -> None:
        
        desc = self.get_descriptor()
        log_entry_c = log_entry.encode('l1')
        if isinstance(log_entry_time, datetime):
            log_entry_time_c = int((log_entry_time - FILETIME_epoch).total_seconds())
        elif isinstance(log_entry_time, int) and log_entry_time == 0:
            log_entry_time_c = int((datetime.now() - FILETIME_epoch).total_seconds()*1e7)
        else:
            log_entry_time_c = int(log_entry_time + desc.time_zero)
        rv = TwRetVal(td.TwAddLogEntry(log_entry_c, log_entry_time_c))

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoActiveAcquisition:
            raise TofDaqNoActiveAcquisitionError(rv.value, "No active acquisition")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value)
        else:
            raise TofDaqException(rv.value)

    def add_attribute(self, obj_name: str, attribute_name: str, value: Union[int, float, str]) -> None:
        
        obj_name_c = obj_name.encode('l1')
        attribute_name_c = attribute_name.encode('l1')
        if isinstance(value, int):
            rv = TwRetVal(td.TwAddAttributeInt(obj_name_c, attribute_name_c, value))
        elif isinstance(value, float):
            rv = TwRetVal(td.TwAddAttributeDouble(obj_name_c, attribute_name_c, value))
        elif isinstance(value, str):
            value = value.encode('l1')
            rv = TwRetVal(td.TwAddAttributeString(obj_name_c, attribute_name_c, value))
        else:
            raise TypeError(f"Invalid type {type(value)} for parameter value")

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoActiveAcquisition:
            raise TofDaqNoActiveAcquisitionError(rv.value, "No active acquisition")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value)
        else:
            raise TofDaqException(rv.value)

    def rds_add_user_data(self, location: str, data: npt.NDArray[np.float64], element_description: Union[List[str], None] = None,
                     compression_level: int = 4) -> None:
        
        location_c = location.encode('l1')
        if element_description is not None:
            element_description_c = ct.create_string_buffer(len(element_description)*256)
            for idx, el in enumerate(element_description):
                start = idx * 256
                element_description_c[start:start + 256] = el.encode('l1') + bytes(256 - len(el))
        else:
            element_description_c = None

        if data.ndim > 1 and np.shape(data)[0] > 1:
            rv = TwRetVal(td.TwAddUserDataMultiRow(location_c, np.shape(data)[1], np.shape(data)[0],
                                                   element_description_c, data, compression_level))
        else:
            nbr_elements = np.shape(data)[0] if data.ndim == 1 else np.shape(data)[1]
            rv = TwRetVal(td.TwAddUserData(location_c, nbr_elements, element_description_c, data,
                                           compression_level))

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoActiveAcquisition:
            raise TofDaqNoActiveAcquisitionError(rv.value, "No active acquisition")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, f"No successful start was confirmed within {self.get_timeout()} ms")
        elif rv == TwRetVal.TwOutOfBounds:
            raise TofDaqOutOfBoundsError(rv.value, f"Size mismatch between the existing dataset at {location} and the data to be "
                                         f"added - {np.shape(data)}")
        else:
            raise TofDaqException(rv.value)

    def rds_add_source(self, location: str, element_description: List[str], compression_level: int = 4,
                       registered_data_type: RegisteredDataType = RegisteredDataType.buffer) -> None:
        
        location_c = location.encode('l1')
        element_description_c = ct.create_string_buffer(len(element_description) * 256)
        for idx, el in enumerate(element_description):
            start = idx * 256
            element_description_c[start:start + 256] = el.encode('l1') + bytes(256 - len(el))
        nbr_elements = len(element_description)

        if registered_data_type == RegisteredDataType.buffer:
            rv = TwRetVal(td.TwRegisterUserDataBuf(location_c, nbr_elements, element_description_c, compression_level))
        elif registered_data_type == RegisteredDataType.write:
            rv = TwRetVal(td.TwRegisterUserDataWrite(location_c, nbr_elements, element_description_c, compression_level))
        elif registered_data_type == RegisteredDataType.no_store:
            rv = TwRetVal(td.TwRegisterUserDataNoStore(location_c, nbr_elements, element_description_c))
        else:
            raise TypeError("Invalid type specified for the registered data")

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwAcquisitionActive:
            raise TofDaqAcquisitionActiveError(rv.value, "Acquisition already active - cannot register")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value)
        else:
            raise TofDaqException(rv.value)

    def rds_remove_source(self, location: str) -> None:
        
        location_c = location.encode('l1')
        rv = TwRetVal(td.TwUnregisterUserData(location_c))

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwAcquisitionActive:
            raise TofDaqAcquisitionActiveError(rv.value, "Acquisition already active - cannot register")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value)
        else:
            raise TofDaqException(rv.value)

    def rds_get_size(self, location: str) -> int:

        location_c = location.encode('l1')
        rds_size = np.zeros(shape=(1,), dtype=np.int32)
        rv = TwRetVal(td.TwQueryRegUserDataSize(location_c, rds_size))

        if rv == TwRetVal.TwSuccess:
            return int(rds_size[0])
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "Error retrieving the RDS size - location non existing or "
                                                   "TofdaqRec not running")
        else:
            raise TofDaqException(rv.value)


    def rds_update_source_data(self, location: str, data: npt.NDArray[np.float64]) -> None:
        
        location_c = location.encode('l1')
        nbr_elem = self.rds_get_size(location)

        rv = TwRetVal(td.TwUpdateUserData(location_c, nbr_elem, data))

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value)
        else:
            raise TofDaqException(rv.value)


    def rds_get_source_data(self, location: str, data: Union[npt.NDArray[np.float64], None] = None) -> npt.NDArray[np.float64]:
        
        location_c = location.encode('l1')
        nbr_elem = self.rds_get_size(location)
        if data is None:
            data = np.empty(shape=(nbr_elem,), dtype=np.float64)

        rv = TwRetVal(td.TwReadRegUserData(location_c, nbr_elem, data))

        if rv == TwRetVal.TwSuccess:
            return data
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwFileNotFound:
            raise FileNotFoundError(f"Data source specified in Location - {location} - does not exist")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value)
        else:
            raise TofDaqException(rv.value)

    def rds_set_target(self, location: str, element: Union[str, int], value: float, block_time: int = 100) -> None:

        location_c = location.encode('l1')
        if isinstance(element, str):
            element_descriptions = self.rds_get_desc(location)
            element_idx = element_descriptions.index(element)
        else:
            element_idx = element
        value = np.array([value], dtype=np.float64)
        rv = TwRetVal(td.TwSetRegUserDataTarget(location_c, element_idx, value, block_time))

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, f"timeout (either waiting for pending changes flag to go to 0 or waiting for "
                                     f"confirmation after setting the value)")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "Failure to open the registered data source specified by location or "
                                         "the data source does not support setting values or the supplied value is not "
                                         "within the valid range")
        elif rv == TwRetVal.TwOutOfBounds:
            raise TofDaqOutOfBoundsError(rv.value, f"Invalid index for the RDS element - {element_idx}")
        else:
            raise TofDaqException(rv.value)

    def rds_get_target_range(self, location: str, element: Union[str, int]) -> Tuple[float, float]:

        location_c = location.encode('l1')
        if isinstance(element, str):
            element_descriptions = self.rds_get_desc(location)
            element_idx = element_descriptions.index(element)
        else:
            element_idx = element
        min_value = np.empty(shape=(1,), dtype=np.float64)
        max_value = np.empty(shape=(1,), dtype=np.float64)

        rv = TwRetVal(td.TwGetRegUserDataTargetRange(location_c, element_idx, min_value, max_value))

        if rv == TwRetVal.TwSuccess:
            return float(min_value[0]), float(max_value[0])
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoData:
            raise TofDaqNoDataError(rv.value, f"The element specified by elementIndex does not support setting its value")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "Failure to open the registered data source specified by location")
        elif rv == TwRetVal.TwOutOfBounds:
            raise TofDaqOutOfBoundsError(rv.value, f"Invalid index for the RDS element - {element_idx}")
        else:
            raise TofDaqException(rv.value)

    def rds_get_desc(self, location: str) -> List[str]:

        location_c = location.encode('l1')
        nbr_elements = np.array([self.rds_get_size(location)], dtype=np.int32)
        element_description_c = ct.create_string_buffer(int(nbr_elements[0])*256)

        rv = TwRetVal(td.TwGetRegUserDataDesc(location_c, nbr_elements, element_description_c))

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, f"No information was retrieved within {self.get_timeout()} ms")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value)
        elif rv == TwRetVal.TwNoData:
            raise TofDaqNoDataError(rv.value, f"No location named {location} was found in the RDS, or it has no descriptions "
                                    f"(TwInfo) stored with it")
        elif rv == TwRetVal.TwValueAdjusted:
            logger.warning("The size of the RDS was adjusted during the API function call")
        else:
            raise TofDaqException(rv.value)

        element_description = []
        nbr_strings = int(len(element_description_c) / 256)
        for idx in range(0, nbr_strings):
            start = idx * 256
            element_description.append(element_description_c[start:start + 256].decode('l1').strip("\x00"))
        return element_description

    def rds_get_all_sources(self) -> List[RegisteredDataSource]:
        
        nbrSrc = np.zeros((1,), dtype=np.int32)

        rv = TwRetVal(td.TwGetRegUserDataSources(nbrSrc, None, None, None))

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, "Timeout in interprocess communication")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "Mismatch between the array length and the arrays")
        elif rv == TwRetVal.TwValueAdjusted:
            logger.warning("Value adjusted")

        location_c = ct.create_string_buffer(int(nbrSrc[0] * 256))
        nbrElements = np.zeros((nbrSrc[0],), dtype=np.int32)
        dsType = np.zeros((nbrSrc[0],), dtype=np.int32)

        rv = TwRetVal(td.TwGetRegUserDataSources(nbrSrc, location_c, nbrElements, dsType))

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, "Timeout in interprocess communication")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "Mismatch between the array length and the arrays")
        elif rv == TwRetVal.TwValueAdjusted:
            logger.warning("Value adjusted")

        locations = []
        nbr_strings = int(len(location_c) / 256)
        for idx in range(0, nbr_strings):
            start = idx * 256
            locations.append(location_c[start:start + 256].decode('l1').strip("\x00"))
        rds_list = []
        for loc, type in zip(locations, dsType):
            desc = self.rds_get_desc(loc)
            rds_list.append(RegisteredDataSource(location=loc, description=desc, type=RegisteredDataType(type)))

        return rds_list

    def tps_connect(self, ip: str = "localhost", tpsType: int = 1) -> None:
        
        rv = TwRetVal(td.TwTpsConnect2(ip.encode('utf-8'), tpsType))

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "Failed to connect")
        else:
            raise TofDaqException(rv.value)

    def tps_disconnect(self) -> None:
        
        rv = TwRetVal(td.TwTpsDisconnect())

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "TPS not connected")
        else:
            raise TofDaqException(rv.value)

    def tps_get_monitor_value(self, rc_code: int) -> float:
        
        value = np.empty(shape=(1,), dtype=np.float64)
        rv = TwRetVal(td.TwTpsGetMonitorValue(rc_code, value))

        if rv == TwRetVal.TwSuccess:
            return float(value[0])
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "TPS not connected or RC code is not a monitor type")
        elif rv == TwRetVal.TwOutOfBounds:
            raise TofDaqOutOfBoundsError(rv.value, "RC code does not exist")
        else:
            raise TofDaqException(rv.value)


    def tps_get_target_value(self, rc_code: int) -> float:

        value = np.empty(shape=(1,), dtype=np.float64)
        rv = TwRetVal(td.TwTpsGetTargetValue(rc_code, value))

        if rv == TwRetVal.TwSuccess:
            return float(value[0])
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "TPS not connected or RC code is not settable")
        elif rv == TwRetVal.TwOutOfBounds:
            raise TofDaqOutOfBoundsError(rv.value, "RC code does not exist")
        else:
            raise TofDaqException(rv.value)

    def tps_get_last_set_value(self, rc_code: int) -> float:

        value = np.empty(shape=(1,), dtype=np.float64)
        rv = TwRetVal(td.TwTpsGetLastSetValue(rc_code, value))

        if rv == TwRetVal.TwSuccess:
            return float(value[0])
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "TPS not connected or RC code is not settable")
        elif rv == TwRetVal.TwOutOfBounds:
            raise TofDaqOutOfBoundsError(rv.value, "RC code does not exist")
        else:
            raise TofDaqException(rv.value)

    def tps_set_target_value(self, rc_code: int, value: float) -> None:
        
        value = np.float64(value)
        rv = TwRetVal(td.TwTpsSetTargetValue(rc_code, value))

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "TPS not connected or RC code is not of target type")
        elif rv == TwRetVal.TwOutOfBounds:
            raise TofDaqOutOfBoundsError(rv.value, "RC code does not exist")
        else:
            raise TofDaqException(rv.value)

    def tps_get_rc_codes(self) -> List[int]:

        nbr_rc_codes = np.empty(shape=(1,), dtype=np.int32)
        rv = TwRetVal(td.TwTpsGetNbrModules(nbr_rc_codes))

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "TPS not connected")
        else:
            raise TofDaqException(rv.value)

        rc_codes = np.empty(shape=(nbr_rc_codes[0],), dtype=np.int32)
        rv = TwRetVal(td.TwTpsGetModuleCodes(rc_codes, nbr_rc_codes[0]))

        if rv == TwRetVal.TwSuccess:
            return [int(rc) for rc in rc_codes]
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "TPS not connected")
        else:
            raise TofDaqException(rv.value)

    def tps_initialize(self) -> None:
        
        rv = TwRetVal(td.TwTpsInitialize())

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "TPS not connected")
        else:
            raise TofDaqException(rv.value)

    def tps_set_all_voltages(self) -> None:
        
        rv = TwRetVal(td.TwTpsSetAllVoltages())

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "TPS not connected")
        else:
            raise TofDaqException(rv.value)

    def tps_shutdown(self) -> None:
        
        rv = TwRetVal(td.TwTpsShutdown())

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "TPS not connected")
        else:
            raise TofDaqException(rv.value)

    def tps_get_status(self) -> TpsStatus:

        status = np.empty(shape=(1,), dtype=np.int32)
        rv = TwRetVal(td.TwTpsGetStatus(status))

        if rv == TwRetVal.TwSuccess:
            bindata = format(status[0], "7b")
            return TpsStatus(connected=bindata[6] == "1",
                             initialized=bindata[5] == "1",
                             shutdown=bindata[4] == "1",
                             can_change_ion_mode=bindata[3] == "1",
                             ion_mode_supported=bindata[2] == "1",
                             current_ion_mode=IonMode(int(bindata[0:2], 2)))
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "TPS not connected")
        else:
            raise TofDaqException(rv.value)


    def tps_save_set_file(self, set_file: str, set_file_type: SetFileType = SetFileType.web_gui,
                          rds_name: Union[str, None] = None) -> None:
        
        set_file_c = set_file.encode('l1')
        if set_file_type == SetFileType.web_gui:
            rv = TwRetVal(td.TwTpsSaveSetFile(set_file_c))
        elif set_file_type == SetFileType.rc_codes:
            rv = TwRetVal(td.TwTpsSaveSetFileRc(set_file_c))
            if rds_name is not None:
                nbr_elemnts_rds = self.rds_get_size(rds_name)
                rds_elements_desc = self.rds_get_desc(rds_name)
                rds_data = self.rds_get_source_data(rds_name)
                rv = TwRetVal(td.TwTpsSaveRdsToSetFileRc(set_file_c, rds_name, nbr_elemnts_rds, rds_elements_desc,
                                                         rds_data))
        else:
            raise ValueError("Invalid set file type")

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "TPS not connected or no permission to write the set file")
        else:
            raise TofDaqException(rv.value)


    def tps_load_set_file(self, set_file: str, rds_list: Union[List[str], None] = None,
                          rc_list: Union[None, List[int]] = None, include_rc_in_list: Union[None, bool] = None) -> None:
        
        set_file_c = set_file.encode('l1')
        if include_rc_in_list is None and rc_list is not None:
            raise ValueError("The rc list is passed but it is not the include_rc_in_list argument is missing - it is "
                             "unclear if the rc codes in the list passed should be included or excluded")

        if rc_list is None and rds_list is None:
            rv = TwRetVal(td.TwTpsLoadSetFile(set_file_c))
        elif rc_list is not None and include_rc_in_list is not None and rds_list is None:
            if include_rc_in_list:
                white_list_rc = np.array(rc_list, dtype=np.int32)
                white_list_nbr_elem = len(rc_list)
                black_list_rc = None
                black_list_nbr_elem = 0
            else:
                black_list_rc = np.array(rc_list, dtype=np.int32)
                black_list_nbr_elem = len(rc_list)
                white_list_rc = None
                white_list_nbr_elem = 0
            rv = TwRetVal(td.TwTpsLoadSetFile2(set_file_c, black_list_rc, black_list_nbr_elem, white_list_rc,
                                               white_list_nbr_elem))
        elif rds_list is not None:
            if rc_list is not None and include_rc_in_list is not None:
                if include_rc_in_list:
                    white_list_rc = np.array(rc_list, dtype=np.int32)
                    white_list_nbr_elem = len(rc_list)
                    black_list_rc = None
                    black_list_nbr_elem = 0
                else:
                    black_list_rc = np.array(rc_list, dtype=np.int32)
                    black_list_nbr_elem = len(rc_list)
                    white_list_rc = None
                    white_list_nbr_elem = 0
            else:
                white_list_rc = None
                white_list_nbr_elem = 0
                black_list_rc = None
                black_list_nbr_elem = 0

            white_list_rds_nbr_elem = len(rds_list)
            white_list_rds = ct.create_string_buffer(white_list_rds_nbr_elem*256)
            for idx, el in enumerate(rds_list):
                start = idx * 256
                white_list_rds[start:start + 256] = el.encode('l1') + bytes(256 - len(el))

            rv = TwRetVal(td.TwTpsLoadSetFile3(set_file_c, black_list_rc, black_list_nbr_elem, white_list_rc,
                                               white_list_nbr_elem, white_list_rds, white_list_rds_nbr_elem))
        else:
            raise ValueError("Invalid combination of input parameters")

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "TPS not connected or no permission to read the set file")
        elif rv == TwRetVal.TwValueAdjusted:
            logger.warning("some TPS modules weer not set, see debug output for details")
        elif rv == TwRetVal.TwFileNotFound:
            raise FileNotFoundError(rv.value, f"The file {set_file} does not exist")
        else:
            raise TofDaqException(rv.value)

    def tps_get_rc_limits(self, rc_code: int) -> Tuple[float, float]:

        min_lim = np.empty(shape=(1,), dtype=np.float64)
        max_lim = np.empty(shape=(1,), dtype=np.float64)
        rv = TwRetVal(td.TwTpsGetModuleLimits(rc_code, min_lim, max_lim))

        if rv == TwRetVal.TwSuccess:
            return float(min_lim[0]), float(max_lim[0])
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "TPS not connected")
        elif rv == TwRetVal.TwOutOfBounds:
            raise TofDaqOutOfBoundsError(rv.value, "RC code does not exists")
        else:
            raise TofDaqException(rv.value)

    def keep_file_open(self, keep_open: bool) -> None:

        rv = TwRetVal(td.TwKeepFileOpen(keep_open))

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoActiveAcquisition:
            raise TofDaqNoActiveAcquisitionError(rv.value, "No active acquisition")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, "Timeout")
        elif rv == TwRetVal.TwFileNotFound:
            raise FileNotFoundError("acquisition without data file detected")
        else:
            raise TofDaqException(rv.value)

    def tps_get_module_properties(self, rc_code: int) -> TpsModule:

        properties = np.empty(shape=(1,), dtype=np.int32)
        label = ct.create_string_buffer(256)

        rv = TwRetVal(td.TwTpsGetModuleProperties(rc_code, properties, label))

        if rv == TwRetVal.TwSuccess:
            name = label.raw.decode('l1').strip("\x00")
            return TpsModule(name=name, rc_code=rc_code, property=TpsModuleProperties(properties[0]))
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "TPS not connected")
        elif rv == TwRetVal.TwOutOfBounds:
            raise TofDaqOutOfBoundsError(rv.value, "RC code does not exists")
        else:
            raise TofDaqException(rv.value)

    def tps_change_ion_mode(self, ionMode: IonMode) -> None:
        if ionMode == ionMode.positive:
            new_ion_mode = 0
        elif ionMode == ionMode.negative:
            new_ion_mode = 1
        else:
            raise TofDaqInvalidValueError("Invalid value of Ion Mode selected - only positive or negative ion modes"
                                          " are supported")
        timeout_orig = self.get_timeout()
        self.set_timeout(30000)
        rv = td.TwTpsChangeIonMode(new_ion_mode)
        self.set_timeout(timeout_orig)

        if rv != TwRetVal.TwSuccess.value:
            raise TofDaqException(rv=rv, message=f"Could not change the ion mode in the TPS - {rv}")
