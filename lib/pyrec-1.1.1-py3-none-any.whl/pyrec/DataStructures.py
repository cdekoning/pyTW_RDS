"""
Data Structures used by the Pyrec wrapper for returning pythonic objects that can be interpreted intuitively
"""
import ctypes as ct
from dataclasses import dataclass
from typing import List
from enum import Enum
from typing import Any, Dict, Union

import numpy as np


class SharedMemoryDesc:
    """
    Contains information on the current acquisition
    """
    def __init__(self, descriptor: Union[Any, Dict]):
        if isinstance(descriptor, dict):
            self.nbr_samples = int(descriptor["NbrSamples"])
            self.nbr_raw_samples = int(descriptor["NbrRawSamples"])
            self.nbr_peaks = int(descriptor["NbrPeaks"])
            self.nbr_waveforms = int(descriptor["NbrWaveforms"])
            self.nbr_segments = int(descriptor["NbrSegments"])
            self.nbr_blocks = int(descriptor["NbrBlocks"])
            self.nbr_memories = int(descriptor["NbrMemories"])
            self.nbr_bufs = int(descriptor["NbrBufs"])
            self.nbr_writes = int(descriptor["NbrWrites"])
            self.nbr_runs = int(descriptor["NbrRuns"])
            self.i_waveform = int(descriptor["iWaveform"])
            self.i_segment = int(descriptor["iSegment"])
            self.i_block = int(descriptor["iBlock"])
            self.i_memory = int(descriptor["iMemory"])
            self.i_buf = int(descriptor["iBuf"])
            self.i_write = int(descriptor["iWrite"])
            self.i_run = int(descriptor["iRun"])
            self.i_cube = int(descriptor["iCube"]) if "iCube" in descriptor.keys() else None
            self.totalBufsRecorded = int(descriptor["TotalBufsRecorded"])
            self.total_bufs_processed = int(descriptor["TotalBufsProcessed"])
            self.total_bufs_written = int(descriptor["TotalBufsWritten"])
            self.overall_bufs_processed = int(descriptor["OverallBufsProcessed"])
            self.total_nbr_memories = int(descriptor["TotalNbrMemories"])
            self.total_memories_processed = int(descriptor["TotalMemoriesProcessed"])
            self.raw_data_recorded_buf1 = int(descriptor["RawDataRecordedBuf1"])
            self.raw_data_recorded_buf2 = int(descriptor["RawDataRecordedBuf2"])
            self.raw_data_last_element_inBuffer1 = int(descriptor["RawDataLastElementInBuffer1"])
            self.raw_data_last_element_inBuffer2 = int(descriptor["RawDataLastElementInBuffer2"])
            self.raw_data_processed_buf1 = int(descriptor["RawDataProcessedBuf1"])
            self.raw_data_processed_buf2 = int(descriptor["RawDataProcessedBuf2"])
            self.raw_data_written_buf1 = int(descriptor["RawDataWrittenBuf1"])
            self.raw_data_written_buf2 = int(descriptor["RawDataWrittenBuf2"])
            self.sample_interval = float(descriptor["SampleInterval"])
            self.tof_period = int(descriptor["TofPeriod"])
            self.nbr_cubes = int(descriptor["NbrCubes"]) if "NbrCubes" in descriptor.keys() else None
            self.block_period = int(descriptor["BlockPeriod"])
            self.block_pulse_delay = int(descriptor["BlockPulseDelay"])
            self.block_delay = int(descriptor["BlockDelay"])
            self.mass_calib_mode = int(descriptor["MassCalibMode"])
            self.mass_calib_mode2 = int(descriptor["MassCalibMode2"])
            self.nbr_mass_calib_params = int(descriptor["NbrMassCalibParams"])
            self.nbr_mass_calib_params2 = int(descriptor["NbrMassCalibParams2"])
            self.p = list(descriptor["p"])
            self.p2 = list(descriptor["p2"])
            self.single_ion_signal = float(descriptor["SingleIonSignal"])
            self.single_ion_signal2 = float(descriptor["SingleIonSignal2"])
            self.R0 = float(descriptor["R0"])
            self.dm = float(descriptor["dm"])
            self.m0 = float(descriptor["m0"])
            self.second_tof = bool(descriptor["SecondTof"])
            self.ch_ini_file_name = descriptor["chIniFileName"]
            self.current_data_file_name = descriptor["CurrentDataFileName"]
            self.seg_ilf = int(descriptor["segIlf"]) if "segIlf" in descriptor.keys() else None
            self.daq_mode = int(descriptor["DaqMode"])
            self.acquisition_mode = int(descriptor["AcquisitionMode"])
            self.combine_mode = int(descriptor["CombineMode"])
            self.recalib_freq = int(descriptor["RecalibFreq"])
            self.acquisition_log_text = descriptor["AcquisitionLogText"]
            self.acquisition_log_time = int(descriptor["AcquisitionLogTime"])
            self.time_zero = int(descriptor["TimeZero"])
            self.processing_level = int(descriptor["ProcessingLevel"])
            # self.attributeType = int(descriptor.attributeType)
            # self.attributeObject = descriptor.attributeObject.decode()
            # self.attributeName = descriptor.attributeName.decode()
            # self.attributeInt = int(descriptor.attributeInt)
            # self.attributeDouble = float(descriptor.attributeDouble)
            self.enable_var_nbr_memories = int(descriptor["EnableVarNbrMemories"])
            self.nbr_steps = int(descriptor["NbrSteps"])
            self.current_step_at_buf = int(descriptor["CurrentStepAtBuf"])
            self.nbr_memories_for_current_step = int(descriptor["NbrMemoriesForCurrentStep"])
        else:
            self.nbr_samples = int(descriptor.nbrSamples)
            self.nbr_raw_samples = int(descriptor.nbrRawSamples)
            self.nbr_peaks = int(descriptor.nbrPeaks)
            self.nbr_waveforms = int(descriptor.nbrWaveforms)
            self.nbr_segments = int(descriptor.nbrSegments)
            self.nbr_blocks = int(descriptor.nbrBlocks)
            self.nbr_memories = int(descriptor.nbrMemories)
            self.nbr_bufs = int(descriptor.nbrBufs)
            self.nbr_writes = int(descriptor.nbrWrites)
            self.nbr_runs = int(descriptor.nbrRuns)
            self.i_waveform = int(descriptor.iWaveform)
            self.i_segment = int(descriptor.iSegment)
            self.i_block = int(descriptor.iBlock)
            self.i_memory = int(descriptor.iMemory)
            self.i_buf = int(descriptor.iBuf)
            self.i_write = int(descriptor.iWrite)
            self.i_run = int(descriptor.iRun)
            self.i_cube = int(descriptor.iCube)
            self.totalBufsRecorded = int(descriptor.totalBufsRecorded)
            self.total_bufs_processed = int(descriptor.totalBufsProcessed)
            self.total_bufs_written = int(descriptor.totalBufsWritten)
            self.overall_bufs_processed = int(descriptor.overallBufsProcessed)
            self.total_nbr_memories = int(descriptor.totalNbrMemories)
            self.total_memories_processed = int(descriptor.totalMemoriesProcessed)
            self.raw_data_recorded_buf1 = int(descriptor.rawDataRecordedBuf1)
            self.raw_data_recorded_buf2 = int(descriptor.rawDataRecordedBuf2)
            self.raw_data_last_element_inBuffer1 = int(descriptor.rawDataLastElementInBuffer1)
            self.raw_data_last_element_inBuffer2 = int(descriptor.rawDataLastElementInBuffer2)
            self.raw_data_processed_buf1 = int(descriptor.rawDataProcessedBuf1)
            self.raw_data_processed_buf2 = int(descriptor.rawDataProcessedBuf2)
            self.raw_data_written_buf1 = int(descriptor.rawDataWrittenBuf1)
            self.raw_data_written_buf2 = int(descriptor.rawDataWrittenBuf2)
            self.sample_interval = float(descriptor.sampleInterval)
            self.tof_period = int(descriptor.tofPeriod)
            self.nbr_cubes = int(descriptor.nbrCubes)
            self.block_period = int(descriptor.blockPeriod)
            self.block_pulse_delay = int(descriptor.blockPulseDelay)
            self.block_delay = int(descriptor.blockDelay)
            self.mass_calib_mode = int(descriptor.massCalibMode)
            self.mass_calib_mode2 = int(descriptor.massCalibMode2)
            self.nbr_mass_calib_params = int(descriptor.nbrMassCalibParams)
            self.nbr_mass_calib_params2 = int(descriptor.nbrMassCalibParams2)
            self.p = list(descriptor.p)
            self.p2 = list(descriptor.p2)
            self.single_ion_signal = float(descriptor.singleIonSignal)
            self.single_ion_signal2 = float(descriptor.singleIonSignal2)
            self.R0 = float(descriptor.R0)
            self.dm = float(descriptor.dm)
            self.m0 = float(descriptor.m0)
            self.second_tof = bool(descriptor.secondTof)
            self.ch_ini_file_name = descriptor.chIniFileName.decode()
            self.current_data_file_name = descriptor.currentDataFileName.decode()
            self.seg_ilf = bytes(descriptor.segIlf)
            self.daq_mode = int(descriptor.daqMode)
            self.acquisition_mode = int(descriptor.acquisitionMode)
            self.combine_mode = int(descriptor.combineMode)
            self.recalib_freq = int(descriptor.recalibFreq)
            self.acquisition_log_text = descriptor.acquisitionLogText.decode()
            self.acquisition_log_time = int(descriptor.acquisitionLogTime)
            self.time_zero = int(descriptor.timeZero)
            self.processing_level = int(descriptor.processingLevel)
            #self.attributeType = int(descriptor.attributeType)
            #self.attributeObject = descriptor.attributeObject.decode()
            #self.attributeName = descriptor.attributeName.decode()
            #self.attributeInt = int(descriptor.attributeInt)
            #self.attributeDouble = float(descriptor.attributeDouble)
            self.enable_var_nbr_memories = int(descriptor.enableVarNbrMemories)
            self.nbr_steps = int(descriptor.nbrSteps)
            self.current_step_at_buf = int(descriptor.currentStepAtBuf)
            self.nbr_memories_for_current_step = int(descriptor.nbrMemoriesForCurrentStep)

    def __repr__(self) -> str:
        rep = (
       f"DAQ Settings - Data Dimensions ####### | DAQ Settings - Timing ################### "
       f"Samples: {self.nbr_samples}            | SampleInterval: {self.sample_interval}    "              
       f"Segments: {self.nbr_segments}          | TofPeriod: {self.tof_period}              "
       f"Bufs: {self.nbr_bufs}                  | BlockPeriod: {self.block_period}          "
       f"Writes: {self.nbr_writes}              |                                           "
       f"Peaks: {self.nbr_peaks}                |                                           "
       f"                                       |                                           "
       f"Current acquisition ################## | DAQ Settings - Averaging ################ "
       f"Waveform: {self.i_waveform}            | Waveforms: {self.nbr_waveforms}           "
       f"Segment: {self.i_segment}              | Blocks: {self.nbr_blocks}                 "
       f"Block: {self.i_block}                  | Memories: {self.nbr_memories}             "
       f"Memory: {self.i_memory}                |                                           "
       f"Buffer: {self.i_buf}                   |                                           "
       f"Write: {self.i_write}                  |                                           "
       f"Run: {self.i_run}                      |                                           "
       f"Cube: {self.i_cube}                    |                                           "
               )
        return rep


class PeakPar:
    """
    Contains information on a peak from the TofDaqRec Peak list
    """

    def __init__(self, peak_par: Union[Any, Dict]):
        if isinstance(peak_par, dict):
            self.label = peak_par["label"]
            self.mass = peak_par["mass"]
            self.lo_mass = peak_par["loMass"]
            self.hi_mass = peak_par["hiMass"]
        else:
            self.label = peak_par.label.decode()
            self.mass = float(peak_par.mass)
            self.lo_mass = float(peak_par.loMass)
            self.hi_mass = float(peak_par.hiMass)

    def __repr__(self):
        return (f"peak label: {self.label}\n"
                f"m/Q [Th]: {self.mass}\n"
                f"m/Q limits [Th]: {self.lo_mass} - {self.hi_mass}")


@dataclass
class MassCalibrationData:

    """
    Package useful information on the current mass calibration parameters (might refer to a specific segment)
    """

    label: List[str]
    mode: int
    nbr_points: int
    p: np.ndarray[int, np.dtype[np.float64]]
    mass: np.ndarray[int, np.dtype[np.float64]]
    tof: np.ndarray[int, np.dtype[np.float64]]
    weight: np.ndarray[int, np.dtype[np.float64]]
    sis: np.ndarray[int, np.dtype[np.float64]]


class RegisteredDataType(Enum):
    """
    Type of the registered data source - possible values:

        - 0: The data is added asynchronously to the rds, need to be added manually

        - 1: the data is added after each write - if no update is called on the RDS data, the same data is added

        - 2: the data is added after each buff - if no update is called on the RDS data, the same data is added
    """
    no_store = 0
    write = 1
    buffer = 2


@dataclass
class RegisteredDataSource:
    """
    Information on the registered data source in TofDaqRec
    """
    location: str
    description: List[str]
    type: RegisteredDataType


class SetFileType(Enum):
    """
    Type of .set file, possible values:

        - 0: The format is compatible with importing in the web gui, using CAN address.

        - 1: The format is compatible with the TofDaq dll. Uses rc codes and can import values from the rds
    """
    web_gui = 0
    rc_codes = 1


class IonMode(Enum):
    """
    Ion Mode specified for the TPS
    """
    inconsistent = 0
    undetermined = 1
    positive = 2
    negative = 3


@dataclass
class TpsStatus:
    """
    Contains information on the TPS status
    """
    connected: bool
    initialized: bool
    shutdown: bool
    can_change_ion_mode: bool
    ion_mode_supported: bool
    current_ion_mode: IonMode


# class NmtStatus(Enum):
#     boot_up = 0
#     stopped = 4
#     operational = 5
#     pre_operational = 127
#
#
# class NmtCommand(Enum):
#     operational = 1
#     stop = 2
#     pre_operational = 128
#     reset_node = 129
#     reset_communication = 130


class TpsModuleProperties(Enum):
    """
    possible types of TPS module
    """
    has_monitor = 0
    is_settable = 1
    is_trigger = 2


@dataclass
class TpsModule:
    """
    Contain information on a single TPS module, identified by an RC code
    """
    name: str
    rc_code: int
    property: TpsModuleProperties


class MassSpectrumData:
    """
    Container for information on the mass spectrum. Depending on the way the TofDaq Api was called, some of its fields
    might be left empty to improve performance. By default, all fields are populated using multiple API calls, and the
    returned object contains information on the mass spectrum, the x-axis and the time interval to which the spectrum
    refers, specified by two datetime values.

    An empty container with the appropriate size for storing data can be generated by passing the number of samples
    available in a spectrum - this pre-generated container can be passed to functions retrieving a spectrum during
    acquisition for a small speed increase
    """

    def __init__(self, nbr_samples: Union[int, None] = None):
        self.time_units = ""
        self.x_axis_units = ""
        self.spectrum_units = ""
        self.spectrum = np.empty(shape=(nbr_samples,), dtype=np.float64) if nbr_samples else None
        self.x_axis = np.empty(shape=(nbr_samples,), dtype=np.float64) if nbr_samples else None
        self.time = None

    def __repr__(self):
        spectrum_str = f"Spectrum: array of shape {np.shape(self.spectrum)}, units {self.spectrum_units}" if self.spectrum_units else ""
        x_axis_str = f"X Axis: array of shape {np.shape(self.x_axis)}, units {self.x_axis_units}" if self.x_axis_units else ""
        time_str = f"Time bin: {self.time[0]} - {self.time[1]}" if self.time else ""
        return "\n".join([spectrum_str, x_axis_str, time_str])


@dataclass
class SegmentProfileData:
    """
    Container for information on the profile of a peak across different segments
    """
    peak_label: str
    profile: np.ndarray[int, np.dtype[np.float32]]
    profile_unit: str


class ReturnType(Enum):
    """
    Specifies the type of return obtained from function that retrieve mass spectra or generally large amount of data
    during acquisition.

    Two return types are implemented:

        - array (0): Only the minimal information will be returned. Make the functions between 5-10 times faster.
                     E.g.: when retrieving a spectrum, only the array corresponding to the intensities will be read and returned

        - spectrum (1): A more compete package of information is returned. This is the default option.
                        E.g.: when retrieving a spectrum, not only the intensities but also the associated mass axis
                        and the time interval associated to the spectrum are returned
    """
    array = 0
    spectrum = 1


class DioState(Enum):
    """
    State of the digital input/output
    """
    idle = 0
    active = 1
    pulsed = 2
    manual = 3


class ConfigWindow(Enum):
    """
    Available Tabs in the configuration window of TofDaqRec
    """
    daq_tab = 0
    basic_timing_tab = 1
    advanced_timing_tab = 2
    file_paths_tab = 3
    mass_cal_tab = 4
    h5_tab = 5
    tps_tab = 6

