"""
Sub-Module containing the class modeling a remote TofDaqRec with its methods, wrapping the TofDaqDll in a
pythonic way
"""
import copy
from datetime import datetime, timedelta
from time import altzone, daylight, timezone
import logging
from typing import Union, List, Tuple, Any
import numpy as np
import numpy.typing as npt
import requests
from requests.models import Response
import sys
from pathlib import Path
import json
import base64
import struct
import re
from bs4 import BeautifulSoup
from concurrent.futures import ThreadPoolExecutor

sys.path.append(str(Path(__file__).absolute().parent.parent))
from . import TwTool as tt
from pyrec.TofDaqRec import TofDaqRec
from pyrec.DataStructures import (SharedMemoryDesc, PeakPar, MassCalibrationData,
                                  RegisteredDataType, RegisteredDataSource, TpsStatus, IonMode,
                                  TpsModule, MassSpectrumData, SetFileType, SegmentProfileData,
                                  DioState, ConfigWindow, ReturnType)

from pyrec.DaqExceptions import (TwRetVal, TofDaqRecNotRunningError, TofDaqNoDataError,
                                 TofDaqValueAdjustedWarning,
                                 TofDaqTimeoutError, TofDaqUnspecifiedError,
                                 TofDaqInvalidValueError, TofDaqInvalidParameterError, TofDaqOutOfBoundsError,
                                 TofDaqAcquisitionActiveError, TofDaqNoActiveAcquisitionError, TofDaqException)

logger = logging.getLogger(__name__)
FILETIME_epoch = datetime(1601, 1, 1) - timedelta(seconds=altzone if daylight else timezone)


class TofDaqRecRemote(TofDaqRec):
    """
    Remote instance of TofDaqRec, controllable through a Web Server running on the client (TofDaqRec) side
    """

    def __init__(self, host: str, port: int):

        self.host = host
        self.port = port
        self.tofdaq_dll_rev = int(1.0E6 * (self.get_dll_version() - 1.99) + 0.5)

        self.original_data_path = None
        self.last_acquisition_start = None
        url = f"http://{self.host}:{self.port}/Directories"
        response = requests.get(url)
        self.tmp_data_path = response.json()['DocumentRoot']

    def _make_ws_request(self, function: str, params: Union[List[Any], None] = None) -> Response:
        """
        Prepare a request for the TofDaqRec client. More information on the available functions and on the parameters
        needed by each is available under http://localhost/TofDaq on a PC where the TofDaqWS is running

        Args:
            function: Name of the function(ust be known to the TofDaqWebServer)
            params: list of parameters

        Returns:
            Response object
        """
        url = f"http://{self.host}:{self.port}/TofDaq?method={function}"
        if params is not None:
            for i, p in enumerate(params):
                if isinstance(p, (str, bytes)):
                    if p[0] == "[" and p[-1] == "]":
                        p = p[1:-1]
                        url += f'&p{i + 1}=[{p}]'
                    else:
                        url += f'&p{i + 1}={p}'
                else:
                    url += f'&p{i + 1}={p}'

        response = requests.get(url)
        response.raise_for_status()
        return response

    def _download_file(self, url: str, path: Path) -> None:

        with requests.get(url, stream=True) as response:
            #response = requests.get(url, stream=True)
            response.raise_for_status()
            file_name = url.split("/")[-1]

            file_path = Path(path, file_name)
            with open(file_path, mode="wb") as file:
                for chunk in response.iter_content(chunk_size=10 * 1024):
                    file.write(chunk)
                print(f"Downloaded file {file_path}")


    def get_dll_version(self) -> float:
        response = self._make_ws_request(function="TwGetDllVersion")
        dll_version = response.json()["result"]
        return dll_version

    def initialize_dll(self) -> None:
        logger.debug("Initialization of the dll from the Web Server not supported")

    def cleanup_dll(self) -> None:
        logger.debug("Cleanup of the dll from the Web Server not supported")

    def is_tofdaq_running(self) -> bool:
        response = self._make_ws_request(function="TwTofDaqRunning")
        return response.json()["result"]

    def is_acquisition_active(self) -> bool:
        response = self._make_ws_request(function="TwDaqActive")
        return response.json()["result"]

    def start_acquisition(self) -> None:
        timeout_orig = self.get_timeout()
        self.set_timeout(30000)
        desc = self.get_descriptor()
        self.original_data_path = str(Path(desc.current_data_file_name).parent)
        self.set_daq_parameter("DataPath", value=self.tmp_data_path)
        self.last_acquisition_start = datetime.now()

        response = self._make_ws_request(function="TwStartAcquisition")
        rv = TwRetVal(response.json()["result"])
        self.set_timeout(timeout_orig)

        if rv == TwRetVal.TwSuccess:
            logger.info("Acquisition Started")
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwAcquisitionActive:
            logger.info("The acquisition is already active - will not be restarted")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, f"No successful start was confirmed within {self.get_timeout()} ms")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "Event abandoned or untreated error")
        else:
            raise TofDaqException(rv.value)

    def stop_acquisition(self) -> None:
        timeout_orig = self.get_timeout()
        self.set_timeout(30000)
        response = self._make_ws_request(function="TwStopAcquisition")
        rv = TwRetVal(response.json()["result"])
        self.set_timeout(timeout_orig)
        self.set_daq_parameter('DataPath', self.original_data_path)

        if rv == TwRetVal.TwSuccess:
            logger.info("Acquisition Stopped")
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoActiveAcquisition:
            logger.info("The acquisition has already been stopped")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, f"No successful stop was confirmed within {self.get_timeout()} ms")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "Event abandoned or untreated error")
        else:
            raise TofDaqException(rv.value)

    def continue_acquisition(self) -> None:
        timeout_orig = self.get_timeout()
        self.set_timeout(30000)
        response = self._make_ws_request(function="TwContinueAcquisition")
        rv = TwRetVal(response.json()["result"])
        self.set_timeout(timeout_orig)

        if rv == TwRetVal.TwSuccess:
            logger.info("Acquisition Continuing")
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoActiveAcquisition:
            raise TofDaqNoActiveAcquisitionError(rv.value, "No active acquisition to continue")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, f"No successful continue was confirmed within {self.get_timeout()} ms")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "TofDaqRec does not expect a continue signal")
        else:
            raise TofDaqException(rv.value)

    def manual_continue_needed(self) -> bool:
        response = self._make_ws_request(function="TwContinueAcquisition")
        return response.json()["data"]

    def close_tofdaq_rec(self) -> None:
        timeout_orig = self.get_timeout()
        self.set_timeout(30000)
        response = self._make_ws_request(function="TwCloseTofDaqRec")
        rv = TwRetVal(response.json()["result"])
        self.set_timeout(timeout_orig)

        if rv == TwRetVal.TwSuccess:
            logger.info("TofDaqRec was successfully shutdown")
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, f"No successful shutdown was confirmed within {self.get_timeout()} ms")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value)
        else:
            raise TofDaqException(rv.value)

    def recorder_needs_restart(self) -> bool:
        raise NotImplementedError

    def set_timeout(self, timeout: int) -> None:
        self._make_ws_request(function="TwSetTimeout", params=[timeout])

    def get_timeout(self) -> int:
        response = self._make_ws_request(function="TwGetTimeout")
        return response.json()['timeout']

    def auto_setup_daq_device(self) -> None:

        response = self._make_ws_request(function="TwAutoSetupDaqDevice")
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwAcquisitionActive:
            raise TofDaqAcquisitionActiveError(rv.value, "Active acquisition")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, "No confirmation of successful setup received within 10 seconds")
        else:
            raise TofDaqException(rv.value)

    def initialize_daq_device(self) -> None:

        response = self._make_ws_request(function="TwInitializeDaqDevice")
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwAcquisitionActive:
            raise TofDaqAcquisitionActiveError(rv.value, "Active acquisition")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, "No confirmation of successful setup received within 8 seconds")
        else:
            raise TofDaqException(rv.value)

    def issue_dio4_pulse(self, delay: int, width: int) -> None:

        response = self._make_ws_request(function="TwIssueDio4Pulse", params=[delay, width])
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoActiveAcquisition:
            raise TofDaqNoActiveAcquisitionError(rv.value, "No active acquisition")
        elif rv == TwRetVal.TwOutOfBounds:
            raise TofDaqOutOfBoundsError(rv.value, f"Invalid parameters - either delay ({delay}) or width({width}) < 0")
        else:
            raise TofDaqException(rv.value)

    def set_dio4_state(self, state: DioState) -> None:

        response = self._make_ws_request(function="TwSetDio4State", params=[state.value])
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoActiveAcquisition:
            raise TofDaqNoActiveAcquisitionError(rv.value, "No active acquisition")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "unable to access digital line")
        else:
            raise TofDaqException(rv.value)

    def waiting_for_dio_start_signal(self) -> bool:
        raise NotImplementedError("This function has not been implemented yet in the Web Server for controlling a remote"
                                  " recorder")

    def send_dio_start_signal(self) -> bool:
        raise NotImplementedError(
            "This function has not been implemented yet in the Web Server for controlling a remote"
            " recorder")

    def is_dio_start_delay_active(self) -> bool:

        response = self._make_ws_request(function="TwDioStartDelayActive")
        return response.json()["result"]

    def move_last_acquisition_datafiles(self, destination_path: Union[str, Path] = Path(".")) -> None:
        if isinstance(destination_path, str):
            destination_path = Path(destination_path)

        if self.is_acquisition_active():
            raise TofDaqAcquisitionActiveError(rv=1, message="No file transfer is possible while the acquisition is still active")
        if self.last_acquisition_start is None:
            raise TofDaqUnspecifiedError(rv=5, message="No information on the previous acquisition")

        url = f"http://{self.host}:{self.port}"
        ext = "h5"
        response = requests.get(url, params=ext)
        if response.ok:
            response_text = response.text
        else:
            return response.raise_for_status()

        soup = BeautifulSoup(response_text, 'html.parser')
        datetimes = re.findall(r'\d{2}\-\w{3}\-\d{4} \d{2}\:\d{2}', response_text)
        files = [url + '/' + node.get('href') for node in soup.find_all('a') if node.get('href').endswith(ext)]
        file_mask = [datetime.strptime(file_date, '%d-%b-%Y %H:%M') > self.last_acquisition_start for file_date in datetimes]

        urls = []
        for file, after_last_start_acquisition in zip(files, file_mask):
            if after_last_start_acquisition:
                urls.append(file)

        with ThreadPoolExecutor() as worker:
            worker.map(self._download_file, urls, [destination_path]*len(urls))

    def show_config_window(self, config_window_tab: ConfigWindow = ConfigWindow.daq_tab) -> None:
        response = self._make_ws_request(function="TwShowConfigWindow", params=[config_window_tab.value])
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value)
        else:
            raise TofDaqException(rv.value)

    def load_ini_file(self, ini_filename: Union[str, None] = None) -> None:

        if ini_filename is not None:
            response = self._make_ws_request(function="TwLoadIniFile", params=[ini_filename])
            rv = TwRetVal(response.json()["result"])
        else:
            ini_filename = ""
            response = self._make_ws_request(function="TwLoadIniFile", params=[ini_filename])
            rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwAcquisitionActive:
            raise TofDaqAcquisitionActiveError(rv.value, "Acquisition already active")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, f"No successful file load was confirmed within {self.get_timeout()} ms")
        elif rv == TwRetVal.TwFileNotFound:
            raise FileNotFoundError(rv.value, f"The specified configuration file {ini_filename} could not be found")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, f"The specified configuration file is too long (>255 char)")
        else:
            raise TofDaqException(rv.value)

    def save_ini_file(self, ini_filename: Union[str, None] = None) -> None:
        if ini_filename is not None:
            response = self._make_ws_request(function="TwSaveIniFile", params=[ini_filename])
            rv = TwRetVal(response.json()["result"])
        else:
            ini_filename = ""
            response = self._make_ws_request(function="TwSaveIniFile", params=[ini_filename])
            rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwAcquisitionActive:
            raise TofDaqAcquisitionActiveError(rv.value, "Acquisition already active")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, f"No successful file load was confirmed within {self.get_timeout()} ms")
        elif rv == TwRetVal.TwFileNotFound:
            raise FileNotFoundError(rv.value,
                                    f"The path specified in IniFile - {ini_filename} - does not exist or no permission to create file")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, f"The specified configuration file is too long (>255 char)")
        else:
            raise TofDaqException(rv.value)

    def get_daq_parameter(self, parameter: str) -> Union[str, int, bool, float]:

        response = self._make_ws_request(function="TwGetDaqParameterBool", params=[parameter])
        rv = TwRetVal(response.json()["result"])
        value = response.json()["data"] if "data" in response.json().keys() else None
        if rv == TwRetVal.TwInvalidValue:
            response = self._make_ws_request(function="TwGetDaqParameterNum", params=[parameter])
            rv = TwRetVal(response.json()["result"])
            value = response.json()["data"] if "data" in response.json().keys() else None
            if rv == TwRetVal.TwInvalidValue:
                response = self._make_ws_request(function="TwGetDaqParameterString", params=[parameter])
                rv = TwRetVal(response.json()["result"])
                if "File" in parameter or "Path" in parameter:
                    value = str(Path(response.json()["data"].strip("b'"))) if "data" in response.json().keys() else None
                else:
                    value = response.json()["data"].strip("b'") if "data" in response.json().keys() else None

        if rv == TwRetVal.TwSuccess:
            return value
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwInvalidParameter:
            raise TofDaqInvalidParameterError(rv.value, "Unknown parameter")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, f"No successful file load was confirmed within the timeout")
        elif rv == TwRetVal.TwInvalidValue:
            raise TofDaqInvalidValueError(rv.value, f"Value type not compatible with parameter")
        elif value is None:
            raise TofDaqInvalidValueError(rv.value, f"Value could not be retrieved from tofdaq")
        else:
            raise TofDaqException(rv.value)

    def set_daq_parameter(self, parameter: str, value: Union[str, int, bool, float], auto_adjust_value: bool = True) \
            -> Union[str, int, bool, float]:

        if isinstance(value, str):
            input_value = copy.deepcopy(value)
            response = self._make_ws_request(function="TwSetDaqParameter", params=[parameter, input_value])
            rv = TwRetVal(response.json()["result"])
            if rv == TwRetVal.TwValueAdjusted:
                set_value = self.get_daq_parameter(parameter)
                logger.warning(f"The value for {parameter} was adjusted from {input_value} to {set_value}")
            else:
                set_value = input_value
        else:
            input_value = str(value)
            response = self._make_ws_request(function="TwSetDaqParameter", params=[parameter, input_value])
            rv = TwRetVal(response.json()["result"])
            if rv == TwRetVal.TwValueAdjusted:
                set_value = self.get_daq_parameter(parameter)
                logger.warning(f"The value for {parameter} was adjusted from {input_value} to {set_value}")
            else:
                set_value = input_value

        if rv == TwRetVal.TwSuccess:
            return set_value
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwAcquisitionActive:
            raise TofDaqAcquisitionActiveError(rv.value, "Acquisition already active")
        elif rv == TwRetVal.TwInvalidParameter:
            raise TofDaqInvalidParameterError(rv.value, "Unknown parameter")
        elif rv == TwRetVal.TwInvalidValue:
            raise TofDaqInvalidValueError(rv.value, f"Value type not compatible with parameter")
        elif rv == TwRetVal.TwValueAdjusted:
            if not auto_adjust_value:
                raise TofDaqValueAdjustedWarning(rv.value,
                                                 f"The value could not be set as it should have been adjusted from "
                                                 f"{value} to {set_value}")
            else:
                logger.warning(
                    f"The parameter {parameter} was successfully updated in TofDaqRec, but the set value was "
                    f"adjusted from {value} to {set_value}")
                return set_value
        else:
            raise TofDaqException(rv.value)

    def get_descriptor(self) -> SharedMemoryDesc:
        response = self._make_ws_request(function="TwGetDescriptor")
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            return SharedMemoryDesc(response.json()["data"])
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "Untreated error")
        else:
            raise TofDaqException(rv.value)

    def get_peak_parameters(self, peak_index: int) -> PeakPar:
        response = self._make_ws_request(function="TwGetPeakParameters", params=[peak_index])
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            return PeakPar(response.json()["data"])
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "Untreated error")
        elif rv == TwRetVal.TwOutOfBounds:
            raise TofDaqOutOfBoundsError(rv.value, "The peak index is not in range")
        else:
            raise TofDaqException(rv.value)

    def wait_for_new_data(self, timeout: int = 250, wait_for_event_reset: bool = True) \
            -> SharedMemoryDesc:
        desc = self.get_descriptor()

        response = self._make_ws_request(function="TwWaitForNewData", params=[timeout, wait_for_event_reset])
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            desc.i_buf = response.json()["progress"]["bufIndex"]
            desc.i_write = response.json()["progress"]["writeIndex"]
            return desc
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "Memory mapping failed")
        elif rv == TwRetVal.TwNoData:
            raise TofDaqNoDataError(rv.value, "No data is recorded or memory not yet allocated")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, f"No new data available during {timeout} ms")
        else:
            raise TofDaqException(rv.value)

    def wait_for_end_of_acquisition(self, timeout: int) -> None:

        response = self._make_ws_request(function="TwWaitForEndOfAcquisition", params=[timeout])
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            return
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoActiveAcquisition:
            raise TofDaqNoActiveAcquisitionError(rv.value, "No active acquisition")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, f"No new data available during {timeout} ms")
        else:
            raise TofDaqException(rv.value)

    def get_mass_calibration(self, segment_index: int = 0, buf_index: int = 0) -> MassCalibrationData:

        response = self._make_ws_request(function="TwGetMassCalibFromShMem", params=[segment_index, buf_index])
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, f"No mass calibration data retrieved after {self.get_timeout()} ms")
        else:
            raise TofDaqException(rv.value)

        mc_data = response.json()['data']
        return MassCalibrationData(label=[label for label in mc_data["label"]], mode=mc_data["mode"],
                                   p=np.array(mc_data["parameters"], dtype=np.float64),
                                   mass=np.array(mc_data["mass"], dtype=np.float64),
                                   tof=np.array(mc_data["tof"], dtype=np.float64),
                                   weight=np.array(mc_data["weight"], dtype=np.float64),
                                   nbr_points=len(mc_data["mass"]), sis=np.empty(shape=(1,), dtype=np.float64))

    def set_mass_calibration(self, mass_cal: MassCalibrationData, segment_index: int = 0, buf_index: int = 0) -> None:

        mc_mode = mass_cal.mode
        p = str([float(par) for par in mass_cal.p])
        mass = str([float(m) for m in mass_cal.mass])
        tof = str([float(t) for t in mass_cal.tof])
        weight = str([float(w) for w in mass_cal.weight])
        label = json.dumps(mass_cal.label)
        sis = float(mass_cal.sis[0])
        response = self._make_ws_request(function="TwSetMassCalibInShMem",
                                         params=[mc_mode, p, mass, tof, weight, label, sis, segment_index, buf_index])
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            logger.debug(f"Mass Calibration successfully set for segment {segment_index} and buffer{buf_index}")
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, f"No mass calibration data could be set in {self.get_timeout()} ms")
        elif rv == TwRetVal.TwAcquisitionActive:
            raise TofDaqAcquisitionActiveError(rv.value, "Acquisition already active")
        else:
            raise TofDaqException(rv.value)

    def get_sum_spectrum(self, spectrum: Union[npt.NDArray[np.float64], None] = None, normalize: bool = True,
                         return_type: ReturnType = ReturnType.spectrum) -> MassSpectrumData:

        if normalize == True:
            unit = "[counts/extr.]"
        else:
            unit = "[counts]"

        desc = self.get_descriptor()
        response = self._make_ws_request(function="TwGetSumSpectrumFromShMem",
                                         params=[normalize, 1])
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoData:
            raise TofDaqNoDataError(rv.value, f"Sum spectrum data not available")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value)
        else:
            raise TofDaqException(rv.value)

        sum_spectrum = np.array(struct.unpack(f'{response.json()["data_nElements"]}d',
                                                base64.b64decode(response.json()["data"])),
                                  dtype=np.float64)

        result = MassSpectrumData(desc.nbr_samples)
        if return_type == ReturnType.array:
            result.spectrum = sum_spectrum
            result.spectrum_units = unit
        elif return_type == ReturnType.spectrum:
            last_buf_index_shm = (desc.total_bufs_processed - 1) % desc.nbr_bufs
            last_write_index_shm = (desc.total_bufs_processed - 1) // desc.nbr_bufs
            prev_buf_index_shm = (desc.total_bufs_processed - desc.nbr_bufs - 1) % desc.nbr_bufs
            prev_write_index_shm = (desc.total_bufs_processed - desc.nbr_bufs - 1) // desc.nbr_bufs
            ms = self.get_tof_spectrum(start_segment=0, end_segment=desc.nbr_segments-1, buf_index=last_buf_index_shm,
                                       return_type=ReturnType.spectrum)

            result.spectrum = sum_spectrum
            result.spectrum_units = unit
            result.x_axis = ms.x_axis
            result.x_axis_units = ms.x_axis_units
            start_time_buf = desc.time_zero + self.get_spec_time(last_buf_index_shm, last_write_index_shm) * 1e7
            end_time_buf = start_time_buf + (start_time_buf - desc.time_zero -
                                             self.get_spec_time(prev_buf_index_shm,
                                                                prev_write_index_shm) * 1e7) / desc.nbr_bufs
            result.time = (FILETIME_epoch + timedelta(microseconds=start_time_buf // 10),
                           FILETIME_epoch + timedelta(microseconds=end_time_buf // 10))
        else:
            raise ValueError(f"Invalid return type {return_type}")

        return result

    def get_tof_spectrum(self, spectrum: Union[npt.NDArray[np.float32], None] = None, start_segment: int = 0,
                         end_segment: int = 0, buf_index: int = -1, normalize: bool = True,
                         return_type: ReturnType = ReturnType.spectrum) -> MassSpectrumData:

        if start_segment == -1:
            if end_segment == -1:
                if normalize == True:
                    normalize = False
                    logger.warning(
                        "When the spectra from all segments are returned concatenated, no normalization can be "
                        "applied. The returned unit is switched to counts")
            else:
                raise TofDaqInvalidValueError("If start_segment=-1, must be that also end_segment=-1")
        elif end_segment == -1:
            raise TofDaqInvalidValueError("If end_segment=-1, mst be that also start_segment=-1")

        desc = self.get_descriptor()
        if buf_index == -1:
            buf_index = (desc.total_bufs_processed - 1) % desc.nbr_bufs

        if normalize == True:
            unit = "[counts/extr.]"
        else:
            unit = "[counts]"

        if return_type == ReturnType.array:
            response = self._make_ws_request(function="TwGetTofSpectrumFromShMem",
                                             params=[start_segment, end_segment, buf_index, normalize, 1])
        elif return_type == ReturnType.spectrum:
            response = self._make_ws_request(function="TwGetTofSpectrumFromShMem",
                                             params=[start_segment, end_segment, buf_index, normalize, 3])
        else:
            raise ValueError(f"Invalid return type {return_type}")
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoData:
            raise TofDaqNoDataError(rv.value, "Tof spectrum data not available")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value)
        elif rv == TwRetVal.TwOutOfBounds:
            raise TofDaqOutOfBoundsError(rv.value, "At least one of the indices is out of valid range")
        else:
            raise TofDaqException(rv.value)

        spectrum = np.array(struct.unpack(f'{response.json()["data_nElements"]}f',
                                              base64.b64decode(response.json()["data"])),
                                dtype=np.float32)

        result = MassSpectrumData()
        result.spectrum = spectrum
        result.spectrum_units = unit
        if return_type == ReturnType.spectrum:
            mass_axis = np.array(struct.unpack(f'{response.json()["mass_nElements"]}d',
                                               base64.b64decode(response.json()["mass"])),
                                 dtype=np.float64)
            result.x_axis = mass_axis
            result.x_axis_units = "m/Q [Th]"
            last_write_index_shm = (desc.total_bufs_processed - 1) // desc.nbr_bufs
            prev_write_index_shm = (desc.total_bufs_processed - desc.nbr_bufs - 1) // desc.nbr_bufs
            start_time_buf = desc.time_zero + self.get_spec_time(buf_index, last_write_index_shm) * 1e7
            end_time_buf = start_time_buf + (start_time_buf - desc.time_zero -
                                             self.get_spec_time(buf_index, prev_write_index_shm) * 1e7) / desc.nbr_bufs
            result.time = (FILETIME_epoch + timedelta(microseconds=start_time_buf // 10),
                           FILETIME_epoch + timedelta(microseconds=end_time_buf // 10))

        return result

    def get_mass_axis(self, specAxis: Union[npt.NDArray[np.float64], None] = None, start_segment: int = -1,
                      end_segment: int = -1, buf_index: int = -1) -> Tuple[npt.NDArray[np.float64], str]:

        desc = self.get_descriptor()
        if start_segment == -1:
            start_segment = 0
        if end_segment == -1:
            end_segment = desc.nbr_segments - 1
        if buf_index == -1:
            buf_index = (desc.total_bufs_processed - 1) % desc.nbr_bufs

        segments = range(start_segment, end_segment + 1)
        x_axis = np.empty(shape=(desc.nbr_samples,), dtype=np.float64)

        mc = self.get_mass_calibration(segment_index=start_segment, buf_index=buf_index)
        p = np.empty(shape=(len(segments), len(mc.p)), dtype=np.float64)
        for idx, segment in enumerate(segments):
            mc = self.get_mass_calibration(segment_index=segment, buf_index=buf_index)
            p[idx, :] = mc.p

        p_mean = np.mean(p, axis=0)
        rv = TwRetVal(tt.TwMakeMqAxis(x_axis, mc.mode, p_mean))

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value)
        else:
            raise TofDaqException(rv.value)

        return x_axis, "m/Q [Th]"


    def get_stick_spectrum(self, stick_spectrum: Union[npt.NDArray[np.float32], None] = None,
                           masses: Union[npt.NDArray[np.float32], None] = None, start_segment: int = -1,
                           end_segment: int = -1, buf_index: int = -1,
                           return_type: ReturnType = ReturnType.spectrum) -> MassSpectrumData:

        desc = self.get_descriptor()
        if start_segment == -1:
            start_segment = 0
        if end_segment == -1:
            end_segment = desc.nbr_segments - 1
        if buf_index == -1:
            buf_index = (desc.total_bufs_processed - 1) % desc.nbr_bufs

        if return_type == ReturnType.array:
            response = self._make_ws_request(function="TwGetStickSpectrumFromShMem",
                                             params=[start_segment, end_segment, buf_index, 1])
        elif return_type == ReturnType.spectrum:
            response = self._make_ws_request(function="TwGetStickSpectrumFromShMem",
                                             params=[start_segment, end_segment, buf_index, 3])
        else:
            raise ValueError(f"Invalid return type {return_type}")
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoData:
            raise TofDaqNoDataError(rv.value, "Tof spectrum data not available")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value)
        elif rv == TwRetVal.TwOutOfBounds:
            raise TofDaqOutOfBoundsError(rv.value, "At least one of the indices is out of valid range")
        else:
            raise TofDaqException(rv.value)

        spectrum = np.array(struct.unpack(f'{response.json()["data"]["intensity_nElements"]}f',
                                          base64.b64decode(response.json()["data"]["intensity"])),
                            dtype=np.float32)

        result = MassSpectrumData()
        result.spectrum = spectrum
        result.spectrum_units = "[counts]"
        if return_type == ReturnType.spectrum:
            result.x_axis  = np.array(struct.unpack(f'{response.json()["data"]["mass_nElements"]}f',
                                               base64.b64decode(response.json()["data"]["mass"])),
                                 dtype=np.float64)
            result.x_axis_units = "m/Q [Th]"
            last_write_index_shm = (desc.total_bufs_processed - 1) // desc.nbr_bufs
            prev_write_index_shm = (desc.total_bufs_processed - desc.nbr_bufs - 1) // desc.nbr_bufs
            start_time_buf = desc.time_zero + self.get_spec_time(buf_index, last_write_index_shm) * 1e7
            end_time_buf = start_time_buf + (start_time_buf - desc.time_zero -
                                             self.get_spec_time(buf_index, prev_write_index_shm) * 1e7) / desc.nbr_bufs
            result.time = (FILETIME_epoch + timedelta(microseconds=start_time_buf // 10),
                           FILETIME_epoch + timedelta(microseconds=end_time_buf // 10))

        return result

    def get_segment_profile(self, segment_profile: Union[npt.NDArray[np.float32], None] = None,
                            peak_index: Union[List[int], int] = -1, buf_index: int = -1) -> List[SegmentProfileData]:

        desc = self.get_descriptor()
        if buf_index == -1:
            buf_index = (desc.total_bufs_processed - 1) % desc.nbr_bufs

        if isinstance(peak_index, list):
            response_list = []
            peak_list = []
            for i, pidx in enumerate(peak_index):
                response = self._make_ws_request(function="TwGetSegmentProfileFromShMem",
                                                 params=[pidx, buf_index, 1])
                peak_desc = self.get_peak_parameters(pidx)
                rv = TwRetVal(response.json()["result"])

                if rv == TwRetVal.TwSuccess:
                    pass
                elif rv == TwRetVal.TwDaqRecNotRunning:
                    raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
                elif rv == TwRetVal.TwNoData:
                    raise TofDaqNoDataError(rv.value, f"Data not available for peak index {pidx}")
                elif rv == TwRetVal.TwError:
                    raise TofDaqUnspecifiedError(rv.value)
                elif rv == TwRetVal.TwOutOfBounds:
                    raise TofDaqOutOfBoundsError(rv.value, f"At least one of the indices is out of valid range "
                                                           f"for peak index {pidx}")
                else:
                    raise TofDaqException(rv.value)

                response_list.append(response)
                peak_list.append(peak_desc.label)
        else:
            response = self._make_ws_request(function="TwGetSegmentProfileFromShMem",
                                             params=[peak_index, buf_index, 1])
            rv = TwRetVal(response.json()["result"])

            peak_list = []
            if peak_index == -1:
                desc = self.get_descriptor()
                all_peaks_index = range(0, desc.nbr_peaks)
                for peak_i in all_peaks_index:
                    peak_desc = self.get_peak_parameters(peak_i)
                    peak_list.append(peak_desc.label)
            elif isinstance(peak_index, int):
                peak_desc = self.get_peak_parameters(peak_index)
                peak_list.append(peak_desc.label)
            elif isinstance(peak_index, list):
                for pi in peak_index:
                    peak_desc = self.get_peak_parameters(pi)
                    peak_list.append(peak_desc.label)
            else:
                raise TypeError()

            if rv == TwRetVal.TwSuccess:
                pass
            elif rv == TwRetVal.TwDaqRecNotRunning:
                raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
            elif rv == TwRetVal.TwNoData:
                raise TofDaqNoDataError(rv.value, f"Data not available")
            elif rv == TwRetVal.TwError:
                raise TofDaqUnspecifiedError(rv.value)
            elif rv == TwRetVal.TwOutOfBounds:
                raise TofDaqOutOfBoundsError(rv.value, f"At least one of the indices is out of valid range")
            else:
                raise TofDaqException(rv.value)

            if peak_index == -1:
                response_list = [response]*desc.nbr_peaks
            else:
                response_list = [response]

        profiles = []
        if peak_index == -1:
            seg_profiles = np.array(struct.unpack(f'{response_list[0].json()["data_nElements"]}f',
                                             base64.b64decode(response_list[0].json()["data"])),
                                   dtype=np.float32).reshape(desc.nbr_segments, desc.nbr_peaks)
        elif isinstance(peak_index, int):
            seg_profiles = np.array(struct.unpack(f'{response_list[0].json()["data_nElements"]}f',
                                                  base64.b64decode(response_list[0].json()["data"])),
                                    dtype=np.float32).reshape(desc.nbr_segments, 1)
        elif isinstance(peak_index, list):
            seg_profiles = np.empty(shape=(desc.nbr_segments, len(peak_list)), dtype=np.float32)
            for idx, _ in enumerate(peak_list):
                seg_profiles[:, idx] = np.array(struct.unpack(f'{response_list[idx].json()["data_nElements"]}f',
                                                      base64.b64decode(response_list[idx].json()["data"])),
                                                dtype=np.float32)
        else:
            raise TypeError

        for idx, peak_label in enumerate(peak_list):
            profiles.append(SegmentProfileData(peak_label=peak_label, profile=seg_profiles[:, idx],
                                               profile_unit="[counts/extr.]"))

        return profiles

    def get_spec_time(self, buf_index: int = 0, write_index: int = -1) -> float:

        desc = self.get_descriptor()
        if write_index == -1:
            write_index = desc.i_write
        response = self._make_ws_request(function="TwGetBufTimeFromShMem", params=[buf_index, write_index])
        rv = TwRetVal(response.json()["result"])
        time = response.json()["data"] if "data" in response.json().keys() else None

        if rv == TwRetVal.TwSuccess:
            return float(time)
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoData:
            raise TofDaqNoDataError(rv.value, "Time data not available")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value)
        elif rv == TwRetVal.TwOutOfBounds:
            raise TofDaqOutOfBoundsError(rv.value, "At least one of the indices is out of valid range")
        else:
            raise TofDaqException(rv.value)

    def store_file(self, file_location: str, vfs_location: str):
        raise NotImplementedError

    def add_log_entry(self, log_entry: str, log_entry_time: Union[datetime, int] = 0) -> None:
        desc = self.get_descriptor()
        if isinstance(log_entry_time, datetime):
            log_entry_time_c = int((log_entry_time - FILETIME_epoch).total_seconds())
        elif isinstance(log_entry_time, int) and log_entry_time == 0:
            log_entry_time_c = int((datetime.now() - FILETIME_epoch).total_seconds() * 1e7)
        else:
            log_entry_time_c = int(log_entry_time + desc.time_zero)

        response = self._make_ws_request(function="TwAddLogEntry", params=[log_entry, log_entry_time_c])
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoActiveAcquisition:
            raise TofDaqNoActiveAcquisitionError(rv.value, "No active acquisition")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value)
        else:
            raise TofDaqException(rv.value)

    def add_attribute(self, obj_name: str, attribute_name: str, value: Union[int, float, str]) -> None:
        if isinstance(value, int):
            response = self._make_ws_request(function="TwAddAttributeInt", params=[obj_name, attribute_name, value])
            rv = TwRetVal(response.json()["result"])
        elif isinstance(value, float):
            response = self._make_ws_request(function="TwAddAttributeDouble", params=[obj_name, attribute_name, value])
            rv = TwRetVal(response.json()["result"])
        elif isinstance(value, str):
            response = self._make_ws_request(function="TwAddAttributeString",
                                             params=[obj_name, attribute_name, value])
            rv = TwRetVal(response.json()["result"])
        else:
            raise TypeError(f"Invalid type {type(value)} for parameter value")

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoActiveAcquisition:
            raise TofDaqNoActiveAcquisitionError(rv.value, "No active acquisition")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value)
        else:
            raise TofDaqException(rv.value)

    def rds_add_user_data(self, location: str, data: npt.NDArray[np.float64],
                     element_description: Union[List[str], None] = None, compression_level: int = 4) -> None:

        if data.ndim > 1 and np.shape(data)[0] > 1:
            raise NotImplementedError
        else:
            data_c = np.array2string(data, floatmode='maxprec', separator=', ')
            response = self._make_ws_request(function="TwAddUserData", params=[location,
                                                                               json.dumps(element_description),
                                                                               data_c, compression_level])
            rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoActiveAcquisition:
            raise TofDaqNoActiveAcquisitionError(rv.value, "No active acquisition")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, f"No successful start was confirmed within {self.get_timeout()} ms")
        elif rv == TwRetVal.TwOutOfBounds:
            raise TofDaqOutOfBoundsError(rv.value,
                                         f"Size mismatch between the existing dataset at {location} and the data to be "
                                         f"added - {np.shape(data)}")
        else:
            raise TofDaqException(rv.value)

    def rds_add_source(self, location: str, element_description: List[str], compression_level: int = 4,
                       registered_data_type: RegisteredDataType = RegisteredDataType.buffer) -> None:
        nbr_elements = len(element_description)

        if registered_data_type == RegisteredDataType.buffer:
            response = self._make_ws_request(function="TwRegisterUserDataBuf", params=[location, nbr_elements,
                                                                               json.dumps(element_description),
                                                                               compression_level])
            rv = TwRetVal(response.json()["result"])
        elif registered_data_type == RegisteredDataType.write:
            response = self._make_ws_request(function="TwRegisterUserDataWrite", params=[location, nbr_elements,
                                                                                       json.dumps(element_description),
                                                                                       compression_level])
            rv = TwRetVal(response.json()["result"])
        elif registered_data_type == RegisteredDataType.no_store:
            response = self._make_ws_request(function="TwRegisterUserDataNoStore", params=[location, nbr_elements,
                                                                                         json.dumps(
                                                                                             element_description)])
            rv = TwRetVal(response.json()["result"])
        else:
            raise TypeError("Invalid type specified for the registered data")

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwAcquisitionActive:
            raise TofDaqAcquisitionActiveError(rv.value, "Acquisition already active - cannot register")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value)
        else:
            raise TofDaqException(rv.value)

    def rds_remove_source(self, location: str) -> None:
        response = self._make_ws_request(function="TwUnregisterUserData", params=[location])
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwAcquisitionActive:
            raise TofDaqAcquisitionActiveError(rv.value, "Acquisition already active - cannot register")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value)
        else:
            raise TofDaqException(rv.value)

    def rds_update_source_data(self, location: str, data: npt.NDArray[np.float64]) -> None:
        data_c = np.array2string(data, floatmode='maxprec', separator=', ')

        response = self._make_ws_request(function="TwUpdateUserData", params=[location, data_c])
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value)
        else:
            raise TofDaqException(rv.value)

    def rds_get_source_data(self, location: str, data: Union[npt.NDArray[np.float64], None] = None) -> npt.NDArray[np.float64]:
        response = self._make_ws_request(function="TwGetRegUserData", params=[location])
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            return np.array(response.json()["data"], dtype=np.float64)
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwFileNotFound:
            raise FileNotFoundError(f"Data source specified in Location - {location} - does not exist")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value)
        else:
            raise TofDaqException(rv.value)

    def rds_set_target(self, location: str, element: Union[str, int], value: float, block_time: int = 100) -> None:

        if isinstance(element, str):
            element_descriptions = self.rds_get_desc(location)
            element_idx = element_descriptions.index(element)
        else:
            element_idx = element
        response = self._make_ws_request(function="TwSetRegUserDataTarget", params=[location, element_idx, value, block_time])
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value,
                                     f"timeout (either waiting for pending changes flag to go to 0 or waiting for "
                                     f"confirmation after setting the value)")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value,
                                         "Failure to open the registered data source specified by location or "
                                         "the data source does not support setting values or the supplied value is not "
                                         "within the valid range")
        elif rv == TwRetVal.TwOutOfBounds:
            raise TofDaqOutOfBoundsError(rv.value, f"Invalid index for the RDS element - {element_idx}")
        else:
            raise TofDaqException(rv.value)

    def rds_get_target_range(self, location: str, element: Union[str, int]) -> Tuple[float, float]:

        if isinstance(element, str):
            element_descriptions = self.rds_get_desc(location)
            element_idx = element_descriptions.index(element)
        else:
            element_idx = element

        response = self._make_ws_request(function="TwGetRegUserDataTargetRange",
                                         params=[location, element_idx])
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            return float(response.json()["data"]["minValue"]), float(response.json()["data"]["maxValue"])
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoData:
            raise TofDaqNoDataError(rv.value,
                                    f"The element specified by elementIndex does not support setting its value")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "Failure to open the registered data source specified by location")
        elif rv == TwRetVal.TwOutOfBounds:
            raise TofDaqOutOfBoundsError(rv.value, f"Invalid index for the RDS element - {element_idx}")
        else:
            raise TofDaqException(rv.value)

    def rds_get_size(self, location: str) -> int:
        raise NotImplementedError

    def rds_get_desc(self, location: str) -> List[str]:
        response = self._make_ws_request(function="TwGetRegUserDataDesc", params=[location])
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, f"No information was retrieved within {self.get_timeout()} ms")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value)
        elif rv == TwRetVal.TwNoData:
            raise TofDaqNoDataError(rv.value,
                                    f"No location named {location} was found in the RDS, or it has no descriptions "
                                    f"(TwInfo) stored with it")
        elif rv == TwRetVal.TwValueAdjusted:
            logger.warning("The size of the RDS was adjusted during the API function call")
        else:
            raise TofDaqException(rv.value)

        element_description = response.json()["desc"]
        return element_description

    def rds_get_all_sources(self) -> List[RegisteredDataSource]:
        response = self._make_ws_request(function="TwGetRegUserDataSources")
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, "Timeout in interprocess communication")
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "Mismatch between the array length and the arrays")
        elif rv == TwRetVal.TwValueAdjusted:
            logger.warning("Value adjusted")


        locations = response.json()["data"]["location"]
        types = response.json()["data"]["type"]
        rds_list = []
        for loc, type in zip(locations, types):
            desc = self.rds_get_desc(loc)
            rds_list.append(RegisteredDataSource(location=loc, description=desc, type=RegisteredDataType(type)))

        return rds_list

    def tps_connect(self, ip: str = "localhost", tpsType: int = 1) -> None:
        response = self._make_ws_request(function="TwTpsConnect2", params=[ip, tpsType])
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "Failed to connect")
        else:
            raise TofDaqException(rv.value)

    def tps_disconnect(self) -> None:
        response = self._make_ws_request(function="TwTpsDisconnect")
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "TPS not connected")
        else:
            raise TofDaqException(rv.value)

    def tps_get_monitor_value(self, rc_code: int) -> float:
        response = self._make_ws_request(function="TwTpsGetMonitorValue", params=[rc_code])
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            return response.json()["data"]
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "TPS not connected or RC code is not a monitor type")
        elif rv == TwRetVal.TwOutOfBounds:
            raise TofDaqOutOfBoundsError(rv.value, "RC code does not exist")
        else:
            raise TofDaqException(rv.value)

    def tps_get_target_value(self, rc_code: int) -> float:
        response = self._make_ws_request(function="TwTpsGetTargetValue", params=[rc_code])
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            return response.json()["data"]
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "TPS not connected or RC code is not settable")
        elif rv == TwRetVal.TwOutOfBounds:
            raise TofDaqOutOfBoundsError(rv.value, "RC code does not exist")
        else:
            raise TofDaqException(rv.value)

    def tps_get_last_set_value(self, rc_code: int) -> float:

        response = self._make_ws_request(function="TwTpsGetLastSetValue", params=[rc_code])
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            return response.json()["data"]
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "TPS not connected or RC code is not settable")
        elif rv == TwRetVal.TwOutOfBounds:
            raise TofDaqOutOfBoundsError(rv.value, "RC code does not exist")
        else:
            raise TofDaqException(rv.value)

    def tps_set_target_value(self, rc_code: int, value: float) -> None:

        response = self._make_ws_request(function="TwTpsSetTargetValue", params=[rc_code, value])
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "TPS not connected or RC code is not of target type")
        elif rv == TwRetVal.TwOutOfBounds:
            raise TofDaqOutOfBoundsError(rv.value, "RC code does not exist")
        else:
            raise TofDaqException(rv.value)

    def tps_get_rc_codes(self) -> List[int]:
        response = self._make_ws_request(function="TwTpsGetModuleCodes")
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            return response.json()["data"]
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "TPS not connected")
        else:
            raise TofDaqException(rv.value)

    def tps_initialize(self) -> None:
        response = self._make_ws_request(function="TwTpsInitialize")
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "TPS not connected")
        else:
            raise TofDaqException(rv.value)

    def tps_set_all_voltages(self) -> None:
        response = self._make_ws_request(function="TwTpsSetAllVoltages")
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "TPS not connected")
        else:
            raise TofDaqException(rv.value)

    def tps_shutdown(self) -> None:
        response = self._make_ws_request(function="TwTpsShutdown")
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "TPS not connected")
        else:
            raise TofDaqException(rv.value)

    def tps_get_status(self) -> TpsStatus:
        response = self._make_ws_request(function="TwTpsGetStatus")
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "TPS not connected")
        else:
            raise TofDaqException(rv.value)

        if response.json()["data"]["Current Ionmode"] == "Positive":
            ion_mode = IonMode(2)
        elif response.json()["data"]["Current Ionmode"] == "Negative":
            ion_mode = IonMode(3)
        elif response.json()["data"]["Current Ionmode"] == "Inconsistent":
            ion_mode = IonMode(0)
        elif response.json()["data"]["Current Ionmode"] == "Undetermined":
            ion_mode = IonMode(1)
        else:
            raise ValueError("Invalid ion mode in the TPS")

        status = TpsStatus(connected=response.json()["data"]["Connected"],
                           initialized=response.json()["data"]["Initialized"],
                           shutdown=response.json()["data"]["Shutdown"],
                           can_change_ion_mode=response.json()["data"]["Can change ion mode"],
                           ion_mode_supported=response.json()["data"]["Ion mode change supported"],
                           current_ion_mode=ion_mode)

        return status

    def tps_save_set_file(self, set_file: str, set_file_type: SetFileType = SetFileType.web_gui,
                          rds_name: Union[str, None] = None) -> None:
        raise NotImplementedError

    def tps_load_set_file(self, set_file: str, rds_list: Union[List[str], None] = None,
                          rc_list: Union[None, List[int]] = None, include_rc_in_list: Union[None, bool] = None) -> None:
        raise NotImplementedError

    def tps_get_rc_limits(self, rc_code: int) -> Tuple[float, float]:

        response = self._make_ws_request(function="TwTpsGetModuleLimits", params=[rc_code])
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            return response.json()["data"]["min"], response.json()["data"]["max"]
        elif rv == TwRetVal.TwError:
            raise TofDaqUnspecifiedError(rv.value, "TPS not connected")
        elif rv == TwRetVal.TwOutOfBounds:
            raise TofDaqOutOfBoundsError(rv.value, "RC code does not exists")
        else:
            raise TofDaqException(rv.value)

    def keep_file_open(self, keep_open: bool) -> None:

        response = self._make_ws_request(function="TwKeepFileOpen", params=[keep_open])
        rv = TwRetVal(response.json()["result"])

        if rv == TwRetVal.TwSuccess:
            pass
        elif rv == TwRetVal.TwDaqRecNotRunning:
            raise TofDaqRecNotRunningError(rv.value, "No recording application was found")
        elif rv == TwRetVal.TwNoActiveAcquisition:
            raise TofDaqNoActiveAcquisitionError(rv.value, "No active acquisition")
        elif rv == TwRetVal.TwTimeout:
            raise TofDaqTimeoutError(rv.value, "Timeout")
        elif rv == TwRetVal.TwFileNotFound:
            raise FileNotFoundError("acquisition without data file detected")
        else:
            raise TofDaqException(rv.value)

    def tps_get_module_properties(self, rc_code: int) -> TpsModule:
        raise NotImplementedError

    def tps_change_ion_mode(self, ionMode: IonMode) -> None:
        raise NotImplementedError("This function is not implemented for a remote instance of TofDaqRec")
