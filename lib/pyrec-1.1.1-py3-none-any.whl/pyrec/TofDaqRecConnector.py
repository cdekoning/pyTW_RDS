"""
Module with utility function for connecting to a TofDaqRec instance
"""
from typing import Union
import sys
from pathlib import Path
import logging

sys.path.append(str(Path(__file__).absolute().parent.parent))
from pyrec.TofDaqRec import TofDaqRec
from pyrec.Remote import TofDaqRecRemote

logger = logging.getLogger(__name__)


def get_tofdaqrec(host: Union[str, None] = None, port: Union[int, None] = None) -> TofDaqRec:
    """
    Function returning a TofDaqRec instance, which will be a TofDaqRecLocal instance if not host address is passed or
    a TofDaqRecRemote instance when a host and optionally a port is passed
    Args:
        host (str): ip address of the host for the TofDaqWS
        port: port on hich the TofDaqWs is running

    Returns:
        TofDaqRec instance, which can be used to call the methods of the PyRec high level wrapper for the TofDaqDll

    """
    if host is None:
        from pyrec.Local import TofDaqRecLocal

        return TofDaqRecLocal()
    else:
        if port is None:
            port = 80
        return TofDaqRecRemote(host=host, port=port)
