"""
TofDaqDll high level wrapper for python
"""
